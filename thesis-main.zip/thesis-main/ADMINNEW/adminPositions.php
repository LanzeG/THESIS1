<!DOCTYPE html>
<html lang="en">
<head>
<title>Manage Positions</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<!-- <link rel="stylesheet" href="../css/bootstrap.min.css" />
<link rel="stylesheet" href="../css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="../css/fullcalendar.css" />
<link rel="stylesheet" href="../css/maruti-style.css" />
<link rel="stylesheet" href="../css/maruti-media.css" class="skin-color" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker@3.1.0/daterangepicker.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"> -->
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/daterangepicker@3.1.0/daterangepicker.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>


<?php
include("../DBCONFIG.PHP");
include("../LoginControl.php");
include("../BASICLOGININFO.PHP");

session_start();
$adminId = $_SESSION['adminId'];
$error = false;
$adminname = "SELECT first_name, last_name FROM employees where emp_id = '$adminId'";
$adminnameexecqry = mysqli_query($conn, $adminname) or die ("FAILED TO CHECK EMP ID ".mysqli_error($conn));
$adminData = mysqli_fetch_assoc($adminnameexecqry);

$adminFullName = $adminData['first_name'] . " " . $adminData['last_name'];
if (isset($_POST['addPosition'])) {
    $positionName = $_POST['positionName'];
    $salaryGrade = $_POST['salaryGrade'];

    // Perform the database insertion
    $insertQuery = "INSERT INTO position (position_name, salarygrade) VALUES ('$positionName', '$salaryGrade')";
    $insertResult = mysqli_query($conn, $insertQuery);

    if ($insertResult) {
        $activityLog = "Added a new position ($positionName)";
        $adminActivityQuery = "INSERT INTO adminactivity_log (emp_id, adminname, activity,log_timestamp) VALUES ('$adminId', '$adminFullName','$activityLog', NOW())";
        $adminActivityResult = mysqli_query($conn, $adminActivityQuery);
        ?>
   
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            swal({
             //  title: "Good job!",
              text: "Position inserted successfully",
              icon: "success",
              button: "OK",
             }).then(function() {
                window.location.href = 'adminPositions.php'; // Replace 'your_new_page.php' with the actual URL
            });
        });
     </script>
         <?php
    } else {
        ?><script>
        document.addEventListener('DOMContentLoaded', function() {
            swal({
              // title: "Data ",
              text: "Something went wrong.",
              icon: "error",
              button: "Try Again",
            });
        }); </script>
        <?php
    }

    // Prevent further execution to avoid duplicate alerts
    exit();
}
?> 




  <script type ="text/javascript">

  $( function() {
      $( "#datepicker" ).datepicker({ dateFormat: 'yy-mm-dd'});
      } );
  
</script>
    <title>Manage Positions</title>
</head>
<body>
    
<?php
  include('navbaradmin.php');
  ?>
<div class="title d-flex justify-content-center pt-3">
      <h3>
       MANAGE POSITIONS
      </h3>
    </div>
    <div class="row mt-3 mb-1 d-flex justify-content-end  ">
  <div class="col-10">
  
  </div>
  </div>
  <div id="tab1">
                   
                   
                    <form method="post" action="" >

                    <div class="row">
                        <div class="col-lg-4">
                        <div class="control-group">
                            <label class="control-label" for="positionName">Position:</label>
                            <div class="controls">
                                <input type="text" class="form-control" name="positionName" id="positionName" required>
                            </div>
                        </div>
                        </div>
                        <div class="col-lg-4">
                        <div class="control-group">
                        <label class="control-label" for="salaryGrade">Salary Grade:</label>
                        <div class="controls">
                            <select name="salaryGrade" class="form-control" id="salaryGrade" required>
                                <?php
                                $conn = mysqli_connect("localhost:3307", "root", "", "masterdb");

                                // Query to fetch salary grades from the table
                                $query = "SELECT salarygrade FROM salarygrade";
                                $result = mysqli_query($conn, $query);

                                // Check if there are rows in the result set
                                if ($result && mysqli_num_rows($result) > 0) {
                                    // Loop through the result set and create options for the dropdown
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo "<option value='{$row['salarygrade']}'>{$row['salarygrade']}</option>";
                                    }
                                } else {
                                    // If no salary grades found, display a default option
                                    echo "<option value='' disabled>No salary grades available</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                            </div>
                            <div class="col-lg-4">
                            <label class="control-label" for="monthlySalary">Monthly Salary:</label>
                        <div class="controls">
                            <input type="text" class="form-control" name="monthlySalary" id="monthlySalary" readonly required>
                            </div>
                    </div>
                      
                       

                    <div class="button text-center">
                      
                 
              
                                <button type="submit" class="btn btn-primary mt-3" name="addPosition">Add Position</button>
                                <a href="adminPositions.php" class="btn btn-success mt-3" style= margin-left: 4px;>
                        <span class="icon"><i class="icon-refresh"></i></span> Refresh
                    </a>
                            </div>
                            
                        </div>
                    </form>
                    <br>
                    <tr>

                    <div class="table d-flex align-items-center table-responsive ">
<table class="table table-striped table-bordered ">
<thead class="table-dark">
<th>Position</th>
<th>Salary Grade</th>
<th>Monthly Salary</th>
<th>Actions</th>
</tr>
</thead>
<tbody> 
<?php
$searchquery ="SELECT * FROM position
JOIN salarygrade ON position.salarygrade = salarygrade.salarygrade";                
$searchresult= filterTable($searchquery);

function filterTable($searchquery)
{

  $conn = mysqli_connect("localhost:3307","root","","masterdb");
  $filter_Result = mysqli_query($conn,$searchquery) or die ("failed to query Holidays".mysql_error());
  return $filter_Result;
}while($row1 = mysqli_fetch_array($searchresult)):;
?>
<tr class="gradeX">
<td><?php echo $row1['position_name'];?></td>
<td><?php echo $row1['salarygrade'];?></td>
<td><?php echo $row1['monthlysalary'];?></td>
<td class="col-1 text-center">
<form method="post" action="" class="delete-form ">
                <input type="hidden" name="deletePosition" value="<?php echo $row1['position_name']; ?>">
                <button type="button" class="btn btn-danger delete-button">Delete</button>
            </form>
</td>

<script>
$(document).ready(function() {
  
    $('.delete-button').click(function() {
        var positionName = $(this).closest('form').find('input[name="deletePosition"]').val();

        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this position!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
        .then((willDelete) => {
            if (willDelete) {
                
                $(this).closest('form').submit();
            }
        });
    });
});
</script>
</tr>
<?php endwhile;?>


</tbody>
</table>

</div>

<script>
$(document).ready(function() {
    // Function to update the monthly salary based on the selected salary grade
    function updateMonthlySalary() {
        // Get the selected salary grade from the dropdown
        var selectedSalaryGrade = $('#salaryGrade').val();

        // Use AJAX to fetch the corresponding monthly salary from the server
        $.get('get_monthly_salary.php', { salaryGrade: selectedSalaryGrade }, function(response) {
            // Update the monthlySalary input field with the fetched value
            $('#monthlySalary').val(response);
        })
        .fail(function() {
            console.error('Error fetching monthly salary');
        });
    }

    // Trigger the update on page load
    updateMonthlySalary();
});
</script>

<script>
    $(document).ready(function () {
        // Add change event listener to the salaryGrade dropdown
        $('#salaryGrade').change(function () {
            // Get the selected value
            var selectedSalaryGrade = $(this).val();

            // Make an AJAX request to fetch the corresponding monthly salary
            $.get('get_monthly_salary.php', { salaryGrade: selectedSalaryGrade }, function (response) {
                // Update the monthlySalary input field with the fetched salary
                $('#monthlySalary').val(response);
            })
            .fail(function () {
                console.error('Error fetching monthly salary');
            });
        });
    });
</script>
     
<?php
if (isset($_POST['deletePosition'])) {
    $deletePosition = $_POST['deletePosition'];

 
    $deleteQuery = "DELETE FROM position WHERE position_name = '$deletePosition'";
    $deleteResult = mysqli_query($conn, $deleteQuery);

    if ($deleteResult) {
        
        $activityLog = "Deleted position ($deletePosition)";
        $adminActivityQuery = "INSERT INTO adminactivity_log (emp_id, adminname, activity,log_timestamp) VALUES ('$adminId', '$adminFullName','$activityLog', NOW())";
        $adminActivityResult = mysqli_query($conn, $adminActivityQuery);
        ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                swal({
                    text: "Position deleted successfully",
                    icon: "success",
                    button: "OK",
                }).then(function() {
                    window.location.href = 'adminPositions.php';
                });
            });
        </script>
        <?php
    } else {
        ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                swal({
                    text: "Something went wrong while deleting",
                    icon: "error",
                    button: "Try Again",
                });
            });
        </script>
        <?php
    }

    exit();
}
?>
<?php
unset($_SESSION['masterfilenotif']);
?>

<div class="row-fluid">
<div id="footer" class="span12"> 2023 &copy; WEB-BASED TIMEKEEPING AND PAYROLL SYSTEM USING FINGERPRINT BIOMETRICS</div>
</div>



</html>
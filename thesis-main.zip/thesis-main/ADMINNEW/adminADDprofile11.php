<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker@3.1.0/daterangepicker.css" />
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/daterangepicker@3.1.0/daterangepicker.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<?php
include("../DBCONFIG.PHP");
include("../LoginControl.php");
include("../BASICLOGININFO.PHP");


session_start();

// echo "adminId in this file: ".$_SESSION['adminId'];
$adminId = $_SESSION['adminId'];
$error = false;
$adminname = "SELECT first_name, last_name FROM employees where emp_id = '$adminId'";
$adminnameexecqry = mysqli_query($conn, $adminname) or die ("FAILED TO CHECK EMP ID ".mysqli_error($conn));
$adminData = mysqli_fetch_assoc($adminnameexecqry);

$adminFullName = $adminData['first_name'] . " " . $adminData['last_name'];

$master = $_SESSION['master'];

if (isset($_POST['submit_btn']) ){

  $dateofbirth = $_POST['dob'];
  $datehired = $_POST['dphired'];
  $nationality = $_POST['nationality'];

  $dhired = strtotime($datehired);
  $dt = strtotime('+1 month',$dhired);
  $date13th = date("Y-m-d",$dt);

  // $fingerprintnumber = $_POST['fingerprint'];

  $address = trim($_POST['address']);
  $address = strip_tags($address);
  $address = htmlspecialchars($address,ENT_QUOTES);

  $username = trim($_POST['username']);
  $username = strip_tags($username);
  $username = htmlspecialchars($username);

  $email = trim($_POST['email']);
  $email = strip_tags($email);
  $email = htmlspecialchars($email);

  $lastname = trim($_POST['lastname']);
  $lastname = strip_tags($lastname);
  $lastname = htmlspecialchars($lastname);

  $firstname = trim($_POST['firstname']);
  $firstname = strip_tags($firstname);
  $firstname = htmlspecialchars($firstname);

  $middlename = trim($_POST['middlename']);
  $middlename = strip_tags($middlename);
  $middlename = htmlspecialchars($middlename);

  $gsisidno = ($_POST['gsisidno']);
  $philhealthnumber = ($_POST['philhealthnumber']);
  $tin = ($_POST['tin']);
  $pagibig = ($_POST['pagibignumber']);
  $contact = ($_POST['cellphonenumber']);

  $employoptionvar = ($_POST['employoption']);

  $positionvar = $_POST['position'] ?? '';

  $genderoptionvar = ($_POST['genderoption']);

  $acctoptionvar = ($_POST['acctoption']);
  
  $deptoptionvar = ($_POST['deptoption']);

  $empstatus = ($_POST['empstatusoption']);

  $maritalstatus = ($_POST['maritaloption']);

  $spousename = ($_POST['spousename']);

  $shiftoptionvar = ($_POST['shifttime']);

  $numberofchild = ($_POST['numberofchild']);

  // $child1 = ($_POST['child1name']);

  // $child2 = ($_POST['child2name']);

  // $child3 = ($_POST['child3name']);

  // $child4 = ($_POST['child4name']);

  $files = ($_FILES['image']['tmp_name']);

  // if ($numberofchild == 1 && empty($child1)){
  //   $error = true;
  //   $numberofchilderror = "Number of children do not match with number of children names.";

  // } else if ($numberofchild == 2 && empty($child2)) {
  //   $error = true;
  //   $numberofchilderror = "Number of children do not match with number of children names.";
  
  // } else if ($numberofchild == 3 && empty($child3)){
  //   $error = true;
  //   $numberofchilderror = "Number of children do not match with number of children names.";

  // } else if ($numberofchild == 4 && empty($child4)){
  //   $error = true;
  //   $numberofchilderror = "Number of children do not match with number of children names.";

  // } else if ($numberofchild == 0){

  //   $error = false;
  // }

  if(strlen($address)< 5){
    $error = true;
    $addresserror = "Please provide your complete address.";
  }

  $query ="SELECT user_name FROM employees WHERE user_name ='$username'";
  $result = mysqli_query($conn,$query);
  $count = mysqli_num_rows($result);

  $query1 ="SELECT email FROM employees WHERE email ='$email'";
  $result1 = mysqli_query($conn,$query1);
  $count1 = mysqli_num_rows($result1);

  // if(empty($employoptionvar)){
  //   $error=true;
  //   $employoptionerror = "Please indicate employment type.";
  // } else if($employoptionvar == "Probationary"){
  //   $leaves = 0;
  // }else if($employoptionvar == "Contractual"){
  //   $leaves = 0;

  // }else if($employoptionvar == "Regular"){

  //   $leaves = 15;
  // }

  if ($genderoptionvar == "Male"){
    $splv = 7;
  }else if ($genderoptionvar == "Female"){
    $splv = 60;
  }

  if (empty($files)){
    $error = true;
    $imgerror = "Please provide an image.";
  } else{
      $image = addslashes($_FILES['image']['tmp_name']);
      $name = addslashes($_FILES['image']['name']);
      $image = file_get_contents($image);
      $image = base64_encode($image);
  }


  if ($acctoptionvar == "Administrator"){

    $accounttype = "Administrator";
    $idprefix = "ADMIN-";

  } elseif ($acctoptionvar=="Employee") {

    $accounttype = "Employee";
    $idprefix = "EMP-";
  } elseif ($acctoptionvar=="Master"){
	
	$accounttype = "Master";
  $idprefix = "MSTR-";
  }
  else {
    $error = true;
    $acctError = "Account type not set.";
  }

  if($maritalstatus == "Married" && empty($spousename)){
    $error = true;
    $spouseerror = "Please enter name of spouse.";
  } else if ($maritalstatus == "Single"){
    $spousename = " ";
  }
  
  if ($count!=0){
    $error = true;
    $usernameError = "Username is already in use.";
  }
  if ($count1!=0){
    $error = true;
    $usernameError = "Username is already in use.";
  }

    $basicpay = $_POST['dailyRate'];

    $monthlyrate = ($basicpay * 22);
    $hrate = ($basicpay / 8);

    $mrate = number_format((float)$monthlyrate,2,'.','');


    //GSIS
    if($employoptionvar == "Contractual"){
      $gsisEE = 0;
      $gsisER = 0;
      $gsisTOTAL = 0;
    } else if ($employoptionvar == "Permanent"){
    $gsisEE = $monthlyrate * .09; 
    $gsisER = $monthlyrate * .12; 
    $gsisTOTAL = $gsisEE + $gsisER;
    }

  //philhealth
    if($employoptionvar == "Contractual"){
      $philhealthdeductEE = 0;
      $philhealthdeductER = 0;
      $philhealthdeductTOTAL = 0;
    } else if ($employoptionvar == "Permanent"){
      $philhealthdeductEE = (($mrate * 0.045) / 2);
      $philhealthdeductER = (($mrate * 0.045) / 2);
      $philhealthdeductTOTAL = ($mrate * 0.045);
    }
    
    
    //pagibig
    if($employoptionvar == "Contractual"){
      $pagibigdeductEE = 0;
      $pagibigdeductER = 0;
      $pagibigdeductTOTAL = 0;

    } else if ($employoptionvar == "Permanent"){

    switch ($mrate){

      case ($mrate<=1500):
    
        $pagibigdeductEE = ($mrate*0.01);
        $pagibigdeductER = ($mrate*0.02);
        $pagibigdeductTOTAL = $pagibigdeductEE + $pagibigdeductER;
    
      break;
    
      case ($mrate<=5000):
    
        $pagibigdeductEE = ($mrate*0.02);
        $pagibigdeductER = ($mrate*0.02);
        $pagibigdeductTOTAL = $pagibigdeductEE + $pagibigdeductER;
    
      break;
    
      case ($mrate>5000): 
    
        $pagibigdeductEE = 100.00;
        $pagibigdeductER = 100.00;
        $pagibigdeductTOTAL = $pagibigdeductEE + $pagibigdeductER;
    
      break;
    }
  }

  $datehired1 = DateTime::createFromFormat('Y-m-d', $datehired);
  $currentDate = new DateTime();
  $currentYear = (int)$currentDate->format('Y');
  $sixMonthsLater = clone $datehired1;
  $sixMonthsLater->modify('+1 month');
  
  // leaves
  if ($employoptionvar == "Contractual") {
      $leaves = 0;
  } else if ($employoptionvar == "Permanent") {
      if ($currentDate < $sixMonthsLater) {
          $leaves = 0;
      } else {
          $monthsWorked = (($currentDate->format('Y') - $datehired1->format('Y')) * 12) + $currentDate->format('n') - $datehired1->format('n');
          $leaves = max(0, floor($monthsWorked / 1)) * 1.25;
      }
  }
  
    

  if(!$error){
    $sqlquery = "INSERT INTO employees (user_name, email, last_name, first_name, middle_name, contact_number, acct_type, fingerprint_id, dept_NAME, shift_SCHEDULE, date_hired, prefix_ID, date_of_birth, emp_address, emp_nationality, emp_gender, employment_TYPE, position, img_name, img_tmp, GSIS_idno, PHILHEALTH_idno, PAGIBIG_idno, TIN_number, emp_status, rel_status, rel_partner, num_children, date_plus1month) VALUES 
    ('$username','$email','$lastname','$firstname','$middlename','$contact','$accounttype', '0' ,'$deptoptionvar','$shiftoptionvar','$datehired','$idprefix','$dateofbirth', '$address','$nationality','$genderoptionvar', '$employoptionvar','$positionvar', '$name','$image', '$gsisidno','$philhealthnumber','$pagibig','$tin', '$empstatus', '$maritalstatus', '$spousename', '$numberofchild','$date13th')";
    
    $result = mysqli_query($conn, $sqlquery) or die ("FAILED TO INSERT " . mysqli_error($conn));
    $lastid = mysqli_insert_id($conn);
    $payrollinfoqry = "INSERT INTO PAYROLLINFO (emp_id,base_pay,daily_rate,hourly_rate,gsisEE,gsisER, gsisTOTAL, ph_EE,ph_ER,ph_TOTAL, pagibig_EE,pagibig_ER,pagibig_TOTAL) VALUES ('$lastid','$mrate','$basicpay','$hrate','$gsisEE','$gsisER', '$gsisTOTAL', '$philhealthdeductEE','$philhealthdeductER','$philhealthdeductTOTAL', '$pagibigdeductEE','$pagibigdeductER','$pagibigdeductTOTAL')";
    $payrollinfoexecqry = mysqli_query($conn,$payrollinfoqry) or die ("FAILED TO ADD NEW PAY INFO ".mysqli_error($conn));
    
    $leaveinfoqry = "INSERT INTO leaves (emp_id, leave_count, leaves_year) VALUES ('$lastid', '$leaves', '$currentYear')";
    $leaveexecqry = mysqli_query($conn,$leaveinfoqry) or die ("FAILED TO ADD NEW PAY INFO ".mysqli_error($conn));

    $activityLog = "Added a new employee profile ($firstname $lastname)";
    $adminActivityQuery = "INSERT INTO adminactivity_log (emp_id, adminname, activity,log_timestamp) VALUES ('$adminId', '$adminFullName','$activityLog', NOW())";
    $adminActivityResult = mysqli_query($conn, $adminActivityQuery);
    
    if ($result) {
        for ($i = 1; $i <= $numberofchild; $i++) {
            $childname = $_POST["child" . $i . "name"];
            $childsql = "UPDATE employees SET child_" . $i . " = '$childname' WHERE emp_id = $lastid";
            
            if ($conn->query($childsql) !== TRUE) {
                echo "Error: " . $childsql . "<br>" . $conn->error;
            }
        }
    }
    
   
   ?>

<script>
   document.addEventListener('DOMContentLoaded', function() {
       swal({
        //  title: "Good job!",
         text: "Data inserted successfully",
         icon: "success",
         button: "OK",
        }).then(function() {
           window.location.href = 'adminMasterfile.php'; // Replace 'your_new_page.php' with the actual URL
       });
   });
</script>
    <?php
  } else {
    $errType = "danger";
    // $_SESSION['addprofilenotif'] = "Something went wrong. Make sure you accomplish all the required fields.";
    ?><script>
    document.addEventListener('DOMContentLoaded', function() {
        swal({
          // title: "Data ",
          text: "Something went wrong.",
          icon: "error",
          button: "Try Again",
        });
    }); </script>
    <?php
  }
}
  

?>

<script type ="text/javascript">
  $( function() {
      $( "#datepicker" ).datepicker({ dateFormat: 'yy-mm-dd'});
      } );
  $( function() {
      $( "#birthdate" ).datepicker({ 
        changeYear: true,
        yearRange: "1940:2023",
        dateFormat: 'yy-mm-dd'});
      } );
</script>

    <title>Document</title>
</head>
<body>
<?php
  include('navbaradmin.php');
  ?>

  <div class="content">
  <?php
                if( isset($errMSG)){
                  ?>
                  <div class="form-group">
                    <div class="alert alert=<?php echo ($errType=="success") ? "success" : $errType; ?>">
                      <font color="green" size ="3px"><span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?></font>
                    </div>
                  </div>
                <?php
                }    
                ?>
  <form action="adminADDprofile.php" method="POST" class="form-horizontal" enctype="multipart/form-data">

      <div class="row pt-3">
        
            <div class="col-8 card shadow">
                <div class="title mt-2 d-flex justify-content-center">
                    <h4>Personal Information</h4>
                </div>
                <div class="row">
                    <div class="col-4">
                    <input type="text" class="form-control span11" placeholder="Last name" name="lastname" required/>
                    <div class="d-flex justify-content-center">
                    <label class="control-label">Last Name</label>

                    </div>

                    
                    </div>

                    <?php echo $nameError; ?>
                    </div>
                    <div class="col-4">
                    <input type="text" class="form-control span11" placeholder="Middle Name" name="middlename" required/>
                    <div class="d-flex justify-content-center">
                    <label class="control-label">Middle Name</label>

                    </div>

                    <?php echo $nameError; ?>
                    </div>
                   
                </div>
                <div class="row">
                    <div class="col-6">
aa
                    </div>
                    <div class="col-6">
                        aa
                    </div>
                </div>


            </div>
            <!-- end ng unang side -->
            <div class="col-4 card shadow">
aaa
            </div>
      </div>
      <!-- end ng row -->

      </form>
      <!-- end ng form -->
   
  </div>


  <?php
unset($_SESSION['addprofilenotif']);
?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<script>
    function toggleChildFields() {
      var numberOfChildren = document.getElementById("numberofchild").value;
      var childFieldsContainer = document.getElementById("childFieldsContainer");

      // Clear previous child fields
      childFieldsContainer.innerHTML = "";

      // Generate new child name fields
      for (var i = 1; i <= numberOfChildren; i++) {
        var label = document.createElement("label");
        label.textContent = "Child " + i + ":";

        var input = document.createElement("input");
        input.type = "text";
        input.class = "span11";
        input.placeholder = "Child " + i;
        input.name = "child" + i + "name";

        var controlGroup = document.createElement("div");
        controlGroup.class = "control-group";
        controlGroup.appendChild(label);
        controlGroup.appendChild(document.createElement("br"));
        controlGroup.appendChild(input);

        childFieldsContainer.appendChild(controlGroup);
      }
    }
  </script>

<script>
  function updateDropdowns() {
    var employmentTypeDropdown = document.getElementById('employoption');
    var positionDropdown = document.getElementById('position');
    var salaryGradeInput = document.getElementById('salaryGrade');
    var workingHoursDropdown = document.getElementById('shifttime');

    // Get the selected value in the Employment Type dropdown
    var selectedEmploymentType = employmentTypeDropdown.value;

    // Check if the selected value is "contractual"
    if (selectedEmploymentType.toLowerCase() === 'contractual') {
      // If contractual, make the Position dropdown and Salary Grade input null and disabled
      positionDropdown.value = '';
      positionDropdown.disabled = true;
      salaryGradeInput.value = '';
      salaryGradeInput.disabled = true;

      // Set Working Hours to null for contractual
      workingHoursDropdown.value = '';
    } else {
      // If not contractual, enable the Position dropdown and Salary Grade input
      positionDropdown.disabled = false;
      salaryGradeInput.disabled = false;

      // Set default Working Hours to 8 for permanent
      workingHoursDropdown.value = '8';
    }
  }
</script>




<script>
    function updateSalaryGrade() {
        var position = document.getElementById("position").value;

        if (position !== "") {
            // AJAX request to fetch the salary grade and daily rate
            fetch(`salarygrade.php?position=${position}&ajax=true`)
                .then(response => response.json())
                .then(data => {
                    document.getElementById("salaryGrade").value = data.monthlySalary;

                    // Format the daily rate to two decimal places
                    var formattedDailyRate = data.dailyRate.toFixed(2);
                    document.getElementById("dailyRate").value = formattedDailyRate;
                })
                .catch(error => console.error("Error fetching salary grade:", error));
        } else {
            document.getElementById("salaryGrade").value = "";
            document.getElementById("dailyRate").value = "";
        }
    }
</script>

</body>
</html>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Admin Masterlist</title>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <!-- <link rel="stylesheet" href="../css/bootstrap.min.css" /> -->
<!-- <link rel="stylesheet" href="../css/bootstrap-responsive.min.css" /> -->
<!-- <link rel="stylesheet" href="../css/fullcalendar.css" /> -->
<!-- <link rel="stylesheet" href="../css/maruti-style.css" /> -->
<!-- <link rel="stylesheet" href="../css/maruti-media.css" class="skin-color" /> -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker@3.1.0/daterangepicker.css" />
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/daterangepicker@3.1.0/daterangepicker.min.js"></script>
<script src="../timepicker/jquery.timepicker.min.js"></script>
<script src="../timepicker/jquery.timepicker.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php
include("../DBCONFIG.PHP");
include("../LoginControl.php");
include("../BASICLOGININFO.PHP");

$adminId = $_SESSION['adminId'];
$error = false;
$adminname = "SELECT first_name, last_name FROM employees where emp_id = '$adminId'";
$adminnameexecqry = mysqli_query($conn, $adminname) or die ("FAILED TO CHECK EMP ID ".mysqli_error($conn));
$adminData = mysqli_fetch_assoc($adminnameexecqry);

$adminFullName = $adminData['first_name'] . " " . $adminData['last_name'];

session_start();
$getemp = "SELECT * FROM employees ORDER BY last_name ASC";
$result = mysqli_query($conn, $getemp);

if (isset($_POST['submittime'])) {
   // Get values from the form
   $timein = $_POST['timein'] ?? '00:00';
   $timeout = $_POST['timeout'] ?? '00:00';
   $employeeID = mysqli_real_escape_string($conn, $_POST['emp']);
  //  $lastname = mysqli_real_escape_string($conn, $_POST['emp']);
  $date = mysqli_real_escape_string($conn, $_POST['date']) ?? '0000-00-00';

   
   // Create DateTime objects for time calculations
   $timeinObj = new DateTime($timein);
   $timeoutObj = new DateTime($timeout);
   
   // Initialize variables
   $hourswork = 0;
   $undertime = 0;
   
   // Check morning shift (before 10:30 AM)
   if ($timeinObj < new DateTime('10:30:00')) {
       $hourswork = min(9, ($timeoutObj->diff($timeinObj))->h);
       $undertime = max(0, 9 - $hourswork);
   } else {
       // After 10:30 AM
       // If timeout is later than 7:00 PM, set timeout to 7:00 PM
       if ($timeoutObj > new DateTime('19:00:00')) {
           $timeoutObj = new DateTime('19:00:00');
       }
   
       $hourswork = min(9, ($timeoutObj->diff($timeinObj))->h);
       $undertime = max(0, 9 - $hourswork);
   }
  // Check if the selected employee is valid
  if ($employeeID != "" && !empty($timeout)  && !empty($date)) {
    // Insert data into the timekeeping table
    $insertQuery = "INSERT INTO time_keeping (emp_id, in_morning, out_afternoon, timekeep_day, undertime_hours, hours_work) VALUES ('$employeeID', '$timein', '$timeout', '$date','$undertime', '$hourswork')";
    $insertResult = mysqli_query($conn, $insertQuery);

    if ($insertResult) {
      //dtr
      $dtrQuery = "INSERT INTO dtr (emp_id, in_morning, out_afternoon, hours_worked, DTR_day) values ('$employeeID', '$timein', '$timeout', '$hourswork','$date')";
      $dtrResult = mysqli_query($conn, $dtrQuery);
      //absent
      $deleteQuery = "DELETE FROM absences WHERE emp_id = '$employeeID' AND absence_date = '$date' ";
      $deleteResult = mysqli_query($conn, $deleteQuery);
      //actlog
      $activityLog = "Added a new employee profile ($firstname $lastname)";
     $adminActivityQuery = "INSERT INTO adminactivity_log (emp_id, adminname, activity,log_timestamp) VALUES ('$adminId', '$adminFullName','$activityLog', NOW())";
     $adminActivityResult = mysqli_query($conn, $adminActivityQuery);

        ?>
   
   <script>
   document.addEventListener('DOMContentLoaded', function() {
       swal({
        //  title: "Good job!",
         text: "Data inserted successfully",
         icon: "success",
         button: "OK",
        }).then(function() {
           window.location.href = 'manualtime.php'; // Replace 'your_new_page.php' with the actual URL
       });
   });
</script>
    <?php
    } else {
        echo "Error: " . mysqli_error($conn);
    }
} else {
  ?><script>
  document.addEventListener('DOMContentLoaded', function() {
      swal({
        // title: "Data ",
        text: "Something went wrong.",
        icon: "error",
        button: "Try Again",
      });
  }); </script>
  <?php
}
}

?>






</head>
<script>
  function toggleCollapse() {
    var content = document.getElementById("content1");
    content.classList.toggle("collapsed");
}
</script>
<body>

  <!--Header-part-->

  <?php
  include('navbaradmin.php');
  ?>
<style>
  #content1 {
    display: block;
}

#content1.collapsed {
    display: none;
}
</style>
<div class="title d-flex justify-content-center pt-4">
      <h3>
        Employee Management
      </h3>
    </div>
    
   
  <div id="content">
  <style>
.card1{
    width: 800px;
}
  </style>

  <div class="container card card1 shadow p-3">
   <div class="manual">
    <form action="" method="POST">
        <div class="row">
                  <div class="col-8">
              <label for="employee">Select an Employee</label>
              <select name="emp" class="form-select" id="emp">
                <option value="">Select an employee</option>
                  <?php
                  if ($result) {
                      // Fetch rows from the result set
                      while ($row = mysqli_fetch_array($result)) {
                          // Output an <option> element for each employee
                          echo '<option value="' . $row['emp_id'] . '">' . $row['last_name'] . '</option>';
                      }

                      // Move the fetch to the beginning to get the first row
                      mysqli_data_seek($result, 0);
                      $initialRow = mysqli_fetch_array($result);

                      // Output the initial employee ID directly in the input field
                      echo '<script>document.getElementById("empID").value = ' . $initialRow['emp_id'] . ';</script>';
                  }
                  ?>
              </select>
          </div>
          <div class="col-4">
              <label for="empID">Employee ID</label>
              <input type="text" class="form-control" id="empID" readonly required>
          </div>
          <div class="col-4 mt-2">
            <label for="timein">Enter Time In:</label>
            <input name="timein" type="time" class="form-control" id="timein" required>
         </div>
            <div class="col-4 mt-2">
              <label for="timeout">Enter Time Out:</label>
              <input name="timeout" type="time" class="form-control" id="timeout" required>
            </div>
            <div class="col-4 mt-2">
              <label for="date">Enter Date:</label>
              <input name="date" type="date" class="form-control" id="date" required>
            </div>
        </div>

        <div class="buttons btn-group mt-2 d-flex justify-content-center">
        <!-- <button type="submit"  class="btn btn-info m-2"><i class="fa-solid fa-pen-to-square"></i> Edit Record</button> -->
        <button name ="submittime" type="submit" class="btn btn-success m-3"><i class="fa-solid fa-plus"></i>Add Record</button>
        <!-- <button  type="submit" class="btn btn-danger m-3"><i class="fa-solid fa-trash"></i>Delete Record</button> -->

       

        </div>




    </form>
   </div>
  </div>



<!-- end filter -->

<script>
    // jQuery script to handle dropdown change event
    $(document).ready(function () {
        // When the dropdown changes
        $('#emp').change(function () {
            // Get the selected employee's ID
            var selectedEmpID = $(this).val();

            // Update the empID input field with the selected ID
            $('#empID').val(selectedEmpID);
        });
    });
</script>

<script>
                flatpickr("#timein", {
                    enableTime: true,
                    noCalendar: true,
                    dateFormat: "H:i",
                    time_24hr: true
                });
                flatpickr("#timeout", {
                  enableTime: true,
                  noCalendar: true,
                  dateFormat: "H:i",
                  time_24hr: true
              });
              document.addEventListener("DOMContentLoaded", function () {
                flatpickr("#date", {
                    dateFormat: "Y-m-d", // Adjust the date format as needed
                });
            });
            </script>

</body>

</html>
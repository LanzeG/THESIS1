<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"> -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="style11.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="notificationScript.js"></script>

<!-- Include the new notification styles -->
<link rel="stylesheet" href="notificationStyle.css">

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const showNavbar = (toggleId, navId, bodyId, headerId) => {
                const toggle = document.getElementById(toggleId),
                    nav = document.getElementById(navId),
                    bodypd = document.getElementById(bodyId),
                    headerpd = document.getElementById(headerId);

                // Validate that all variables exist
                if (toggle && nav && bodypd && headerpd) {
                    toggle.addEventListener('click', () => {
                        // show navbar
                        nav.classList.toggle('show');
                        // change icon
                        toggle.classList.toggle('bx-x');
                        // add padding to body
                        bodypd.classList.toggle('body-pd');
                        // add padding to header
                        headerpd.classList.toggle('body-pd');
                    });
                }
            }

            showNavbar('header-toggle', 'nav-bar', 'body-pd', 'header');

            /*===== LINK ACTIVE =====*/
            const linkColor = document.querySelectorAll('.nav_link')

            function colorLink() {
                if (linkColor) {
                    linkColor.forEach(l => l.classList.remove('active'))
                    this.classList.add('active')
                }
            }

            linkColor.forEach(l => l.addEventListener('click', colorLink))
        });
    </script>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            document.querySelectorAll('.sidebar .nav-link').forEach(function (element) {

                element.addEventListener('click', function (e) {

                    let nextEl = element.nextElementSibling;
                    let parentEl = element.parentElement;

                    if (nextEl) {
                        e.preventDefault();
                        let mycollapse = new bootstrap.Collapse(nextEl);

                        if (nextEl.classList.contains('show')) {
                            mycollapse.hide();
                        } else {
                            mycollapse.show();
                            // find other submenus with class=show
                            var opened_submenu = parentEl.parentElement.querySelector('.submenu.show');
                            // if it exists, then close all of them
                            if (opened_submenu) {
                                new bootstrap.Collapse(opened_submenu);
                            }
                        }
                    }
                }); // addEventListener
            }) // forEach
        });
    </script>

    <!-- <script>
        $(function () {
            $('[data-toggle="tooltip"]').tooltip();
        });
    </script> -->

    <style>
        .sidebar li .submenu {
            list-style: none;
            margin: 0;
            padding: 0;
            padding-left: 1rem;
            padding-right: 1rem;
        }


/* Add styles for the notification icon */
.header_notification {
    font-size: 20px;
    cursor: pointer;
}
.notification-dropdown {
    display: none;
    position: absolute;
    top: 30px; /* Adjust this value based on your design */
    right: 0;
    min-width: 200px;
    background-color: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    padding: 10px;
}
.notification-container {
    position: relative;
}

.notification-bell {
    cursor: pointer;
    position: relative;
    display: inline-block;
}

.bell-icon {
    font-size: 24px;
}

    </style>
   <!-- <style>
        /* Tooltip styling */
        .tooltip {
            color: #fff;
            font-size: 14px;
            padding-right:200px; /* Adjust padding to reduce spacing */
        }

        /* Tooltip arrow styling */
        .tooltip .arrow::before {
            border-top-color: #333;
        }
    </style> -->
    <title>Document</title>
</head>

<body id="body-pd">
<header class="header" id="header">
    <div class="header_toggle"> <i class='bx bx-menu' id="header-toggle"></i> ADMIN MANAGEMENT </div>
    <!-- Add the following line for the notification icon -->
    <div id="notification-icon" class="notification-container">
    <span class="bell-icon">&#128276;</span>
    <div class="notification-badge">0</div> <!-- Placeholder for the badge -->
    <div class="notification-dropdown">
        <!-- Notifications will be displayed here -->
    </div>
</div>

</header>
    <div class="l-navbar" id="nav-bar">

        <nav class="nav sidebar">
            
            <div> 
                <a href="#" class="nav_logo"> <i class='bx bx-layer nav_logo-icon'></i> <span class="nav_logo-name">Manage Account</span> </a>

            <div class="nav_list">

<li>            <a href="admintry.php" class="nav_link nav-link  mb-0 " data-bs-toggle="tooltip" data-bs-placement="top" title="Dashboard"  > <i class='bx bx-grid-alt nav_icon'></i>Dashboard</a> 
</li>
            <li class="nav-item">
            <a href="adminactivitylogs.php" class="nav_link nav-link mb-0 " data-bs-toggle="tooltip" data-bs-placement="top" title="Dashboard"  ><i class='bx bx-face nav_icon'></i>Activity Logs</a> 
    </li>
    <li class="nav-item has-submenu ">
    <a href="try.php" class="nav_link nav-link mb-0 mt-1 "  data-bs-toggle="tooltip" data-bs-placement="top" title="Data Management" ><i class='bx bx-message-square-detail nav_icon'> <span style="  font-family: 'Nunito', sans-serif; font-size:1rem;">Manage Data</span> </i> <i class="fa-solid fa-caret-down"></i> </a> 
		<ul class="submenu collapse">
            
			<li><a class="nav-link text-white" href="adminMasterfileTry.php" data-bs-toggle="tooltip" data-bs-placement="top" title="Manage Employee" ><i class='bx bx-user nav_icon'></i> Employees </a></li>
			<li><a class="nav-link text-white" href="adminMasterfileDeptTry.php" data-bs-toggle="tooltip" data-bs-placement="top" title="Manage Department"><i class='bx bx-buildings nav_icon'></i> Department </a></li>
			<li><a class="nav-link text-white" href="adminMasterfileLeave.php" data-bs-toggle="tooltip" data-bs-placement="top" title="Manage Leave" ><i class='bx bx-time nav_icon'></i> Leave </a></li>
            <li><a class="nav-link text-white" href="adminPAYROLLPERIODS.php" data-bs-toggle="tooltip" data-bs-placement="top" title="Manage Payroll Period"><i class='bx bx-calendar nav_icon'></i> Payroll Period </a></li>
            <li><a class="nav-link text-white" href="adminPositions.php" data-bs-toggle="tooltip" data-bs-placement="top" title="Manage"><i class='fa-solid fa-sitemap nav_icon'></i> Positions </a></li>
            <li><a class="nav-link text-white" href="adminSalaryGrades.php" data-bs-toggle="tooltip" data-bs-placement="top" title="Manage Employee"><i class="fa-solid fa-file-invoice-dollar nav_icon"></i> Salary Grades</a></li>


		</ul>
	</li>
    <li class="nav-item has-submenu ">
    <a href="adminMasterfile.php" class="nav_link nav-link mb-2 mt-2 "   data-bs-toggle="tooltip" data-bs-placement="top" title="Manage Attendance" ><i class="fa-solid fa-users nav-icon"><span style="  font-family: 'Nunito', sans-serif; font-size:1rem; padding-left:8px;">Attendance</span> </i> <i class="fa-solid fa-caret-down"></i> </a> 
    <!-- <a href="adminMasterfile.php" class="nav_link nav-link mb-2 mt-2 " > <i class="fa-solid fa-users nav-icon"> <span style="font-family: 'Nunito', sans-serif; font-size:1rem;"Manage Data</span> </i><i class="fa-solid fa-caret-down"></i>  </a> -->
		<ul class="submenu collapse">
			<li><a class="nav-link text-white" href="adminATTENDANCErecordsTry.php"><i class='fa-solid fa-clipboard nav_icon'></i> Records</a></li>
			<li><a class="nav-link text-white" href="adminOT.php"><i class='fa-solid fa-clock nav_icon'></i> Overtime</a></li>
            <li><a class="nav-link text-white" href="adminLeaves.php"><i class="fa-solid fa-users nav-icon"></i> Leaves </a></li>
            <li><a class="nav-link text-white" href="manualtime.php"><i class="fa-solid fa-clock nav_icon"></i> Time In/Out </a></li>



		</ul>
	</li>

    <li class="nav-item has-submenu ">
    <a href="adminMasterfile.php" class="nav_link nav-link mb-2 mt-2 "   data-bs-toggle="tooltip" data-bs-placement="top" title="Payroll Management" ><i class='bx bx-money-withdraw nav-icon'><span style="  font-family: 'Nunito', sans-serif; font-size:1rem; padding-left:8px;"> Payroll</span> </i> <i class="fa-solid fa-caret-down"></i> </a> 

    <!-- <a href="admin/adminPAYROLLINFO.php" class="nav_link nav-link mb-2 mt-2 "> <i class="fa-solid fa-receipt nav-icon"></i> <span class="nav_name">Manage Payroll</span> </a> -->
		<ul class="submenu collapse">
			<li><a class="nav-link text-white" href="adminPAYROLLINFO.php"><i class='fa-solid fa-user nav_icon'></i> Employees</a></li>
			<li><a class="nav-link text-white" href="adminMasterLoans.php"><i class='fa-solid fa-landmark nav_icon'></i> Add Loans </a></li>
            <li><a class="nav-link text-white" href="adminADDLOANSTYPE.php"><i class="fa-solid fa-money-check-dollar nav-icon"></i> Add Loan Type</a></li>
            <li><a class="nav-link text-white" href="adminPAYROLLProcess.php"><i class="fa-solid fa-users nav-icon"></i>Payroll Process  </a></li>
            <!-- <li><a class="nav-link text-white" href="ADMIN/admin13thmonth.php"><i class="fa-solid fa-users nav-icon"></i> 13th Month</a></li> -->
		</ul>
	</li>

    <li class="nav-item has-submenu ">
    <!-- <a href="try.php" class="nav_link nav-link mb-0 mt-3 " > <i class='bx bxs-report nav-icon'></i></i>Reports</a>  -->
    <a href="adminMasterfile.php" class="nav_link nav-link mb-2 mt-2 "   data-bs-toggle="tooltip" data-bs-placement="top" title="Reports" ><i class='bx bxs-report nav-icon'><span style="  font-family: 'Nunito', sans-serif; font-size:1rem; padding-left:8px;"> Reports</span> </i> <i class="fa-solid fa-caret-down"></i> </a> 

		<ul class="submenu collapse">
			<!-- <li><a class="nav-link text-white" href="#"><i class='bx bx-user nav_icon'></i>Timesheet</a></li> -->
			<li><a class="nav-link text-white" href="adminTimesheet.php"><i class='bx bx-buildings nav_icon'></i> DTR</a></li>
			<li><a class="nav-link text-white" href="adminPAYROLLRegister.php"><i class='bx bx-time nav_icon'></i> Payroll Register</a></li>
            <li><a class="nav-link text-white" href="adminPAYROLLPrintPayslip.php"><i class='bx bx-calendar nav_icon'></i> Payslip</a></li>
            <li><a class="nav-link text-white" href="adminGOVTReports.php"><i class='fa-solid fa-sitemap nav_icon'></i> Contributions</a></li>
            <li><a class="nav-link text-white" href="otslip.php"><i class='fa-solid fa-clock nav_icon'></i> Overtime</a></li>

            <li><a class="nav-link text-white" href="adminREPORTyearly.php"><i class="fa-solid fa-file-invoice-dollar nav_icon"></i> Yearly Report</a></li>
            

		</ul>
        
	</li>
    

  
                   
                       
         
                     <!-- <a href="#" class="nav_link"> <i class='bx bx-user nav_icon'></i> <span class="nav_name">Apply Overtime</span> </a>  -->
                     <!-- <a href="admin/adminMasterfile.php" class="nav_link"> <i class='bx bx-message-square-detail nav_icon'></i> <span class="nav_name">Data Management</span> </a>  -->
                     <!-- <a href="admin/adminMasterfile.php" class="nav_link mb-2 mt-2 "> <i class='bx bx-bookmark nav_icon'></i> <span class="nav_name">Attendace Management</span> </a>
                      <a href="adminPAYROLLINFO.php" class="nav_link mb-2 "> <i class='bx bx-folder nav_icon'></i> <span class="nav_name">Payroll</span> </a>
                       <a href="admin/adminTimesheet.php" class="nav_link mb-2"> <i class='bx bx-bar-chart-alt-2 nav_icon'></i> <span class="nav_name">Reports </span></a> -->
                     </div>
                    
    
            </div> <a href="../LOGOUT.php" class="nav_link"> <i class='bx bx-log-out nav_icon'></i> <span class="nav_name">SignOut</span> </a>
        </nav>
    </div>


    <!--Container Main start-->
    

<!-- Your existing HTML content -->

<!-- Include jQuery before your custom script -->
<!-- <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script> -->

<script>
    $(document).ready(function () {
        const bellIcon = $('.bell-icon');
        const notificationDropdown = $('.notification-dropdown');
        const badge = $('.notification-badge');

        function fetchNotifications(markAsRead) {
            console.log(`Fetching notifications (markAsRead: ${markAsRead})...`);
            $.ajax({
                url: `notifications.php?mark_as_read=${markAsRead}`,
                type: 'GET',
                dataType: 'json',
                success: function (data) {
                    console.log('Received data:', data);
                    updateDropdown(data);
                    updateBadge(data.count);
                },
                error: function (error) {
                    console.error('Error fetching notifications:', error);
                }
            });
        }

        function updateDropdown(data) {
    console.log('Updating dropdown with data:', data);
    notificationDropdown.empty();

    if (data.count > 0) {
        $.each(data.notifications, function (index, notification) {
            const link = getNotificationLink(notification); // Function to determine the link based on notification type
            const notificationItem = $('<div>').addClass('notification-item').append($('<a>').attr('href', link).text(notification.message));
            notificationDropdown.append(notificationItem);
        });
    } else {
        const noNotificationItem = $('<div>').text('No new notifications');
        notificationDropdown.append(noNotificationItem);
    }

    // Add "See All Notifications" link
    const seeAllLink = $('<div>').addClass('notification-item see-all').append($('<a>').attr('href', 'all_notifications.php').text('See All Notifications'));
    notificationDropdown.append(seeAllLink);
}

function getNotificationLink(notification) {
    // Function to determine the link based on notification type
    if (notification.type === 'Overtime') {
        return 'adminOT.php';
    } else if (notification.type === 'Leave') {
        return 'adminLEAVES.php';
    }
    else if (notification.type === 'Issue') {
        return 'adminFeedback.php?notification_id=' + notification.notification_id;
    }
     else {
        // Default link
        return '#';
    }
}


        function updateBadge(count) {
            console.log('Updating badge with count:', count);
            badge.text(count);
            badge.css('display', (count > 0) ? 'block' : 'none');
        }

        bellIcon.click(function () {
            console.log('Bell icon clicked');
            notificationDropdown.toggle();

            if (notificationDropdown.is(':visible')) {
                fetchNotifications(true);
            }
        });

        $(document).click(function (event) {
            if (!$(event.target).hasClass('bell-icon') && !$(event.target).closest('.notification-dropdown').length) {
                notificationDropdown.hide();
            }
        });

        // Fetch notifications on page load and update badge
        fetchNotifications(false);
    });
</script>
<!-- <script>
  $(function () {
    $('[data-toggle="tooltip"]').tooltip();
  });
</script> -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js" integrity="sha384-pzjw8f+uxSp2F5R1WNfBpkJLEicf5f8CYEv8BH+LZ8AM+CI0UQTZ2GGSnGOIdRENU" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

</body>
</html>

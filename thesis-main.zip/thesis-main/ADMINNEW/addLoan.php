<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin Home</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker@3.1.0/daterangepicker.css" /> -->
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script> -->

<?php
include("../DBCONFIG.PHP");
include("../LoginControl.php");
include("../BASICLOGININFO.PHP");

session_start();

$adminId = $_SESSION['adminId'];
$error = false;

//for act log hehehehehe
$adminname = "SELECT first_name, last_name FROM employees where emp_id = '$adminId'";
$adminnameexecqry = mysqli_query($conn, $adminname) or die ("FAILED TO CHECK EMP ID ".mysqli_error($conn));
$adminData = mysqli_fetch_assoc($adminnameexecqry);

$adminFullName = $adminData['first_name'] . " " . $adminData['last_name'];




if (isset($_POST['search_btn1'])){

 
  $selectedLoantype = $_POST["loantype"];
  


  // Separate $selectedLoantype into loantype_id and loantype
  list($selectedLoantypeorg, $selectedLoantypeName) = explode('|', $selectedLoantype);
  $_SESSION['selectedLoantype'] = $selectedLoantypeName;
  $_SESSION['selectedLoanorg'] = $selectedLoantypeorg ?? '';


  // echo"<script>alert('hello')</script>";
  $lastname1 = $_POST['lastname'];
  // $loanorg = $_POST['loanorg'];

  if ($selectedLoantypeorg == 'GSIS'){
    $gsisidnoquery = "SELECT * FROM employees where last_name='$lastname1'";
    $gsisidnoexecqry = mysqli_query($conn,$gsisidnoquery);
    $gsisidnocount = mysqli_num_rows($gsisidnoexecqry);
    $gsisidnoarray = mysqli_fetch_array($gsisidnoexecqry);
    if ($gsisidnoarray){
   
      $gsisempid = $gsisidnoarray['emp_id'];
      $last_name = $gsisidnoarray['last_name'];
      $firstname = $gsisidnoarray['first_name'];
      $middlename = $gsisidnoarray['middle_name'];
      $gsis = $gsisidnoarray['GSIS_idno'];
      // $empname = "$lastname, $firstname $middlename"; 
      //  echo"<script>alert($gsis)</script>";

    }else{
      // echo"<script>alert('heafsallo')</script>";
    }
    
  }
  else if($selectedLoantypeorg == 'PAGIBIG'){
    $gsisidnoquery = "SELECT * FROM employees where last_name='$lastname1'";
    $gsisidnoexecqry = mysqli_query($conn,$gsisidnoquery);
    $gsisidnocount = mysqli_num_rows($gsisidnoexecqry);
    $gsisidnoarray = mysqli_fetch_array($gsisidnoexecqry);

    $gsisempid = $gsisidnoarray['emp_id'];
    $last_name = $gsisidnoarray['last_name'];
    $firstname = $gsisidnoarray['first_name'];
    $middlename = $gsisidnoarray['middle_name'];
    $gsis = $gsisidnoarray['PAGIBIG_idno'];
    // $empname = "$lastname, $firstname $middlename"; 
    // echo"<script>alert('hello')</script>";

  }else{
    // echo"<script>alert('heafsallo')</script>";
  }
  
 
  //  $gsisidnoquery = "SELECT * FROM employees where last_name";
  //  echo $gsisidnoquery;
  // $gsisidnoexecqry = mysqli_query($conn,$gsisidnoquery);
  // $gsisidnocount = mysqli_num_rows($gsisidnoexecqry);
  // $gsisidnoarray = mysqli_fetch_array($gsisidnoexecqry);
  // if ($gsisidnoarray){
   
  //   $gsisempid = $gsisidnoarray['emp_id'];
  //   $lastname = $gsisidnoarray['last_name'];
  //   $firstname = $gsisidnoarray['first_name'];
  //   $middlename = $gsisidnoarray['middle_name'];
  //   // $empname = "$lastname, $firstname $middlename"; 

  // }elseif (!$gsisidnoarray){
  //   $error = true;
  //   $gsisidnumbererror = "No Employee has that SSS ID Number.";   
  // }

}

if(isset($_POST['submit_btn'])){
 
  $loantype1 = $_SESSION['selectedLoantype'];
  $loanorg1= $_SESSION['selectedLoanorg'];
  $loanidno = $_POST['loanidno'];
  $gsisempid = $_POST['gsisempid'];

  // $empname = $_POST['empname'];
  $lastname = $_POST['last_name'];
  $firstname = $_POST['first_name'];
  $middlename = $_POST['middle_name'];
  $startdate = $_POST['startpicker'];
  $enddate = $_POST['endpicker'];
  $loanamount = $_POST['loanamount'];
  $monthlydeductionamount = $_POST['monthlydeductionamount'];
  $noofpays = $_POST['payduration'];


 

  $empidqry = "SELECT emp_id FROM employees where emp_id = '$gsisempid'";
  $empidexecqry = mysqli_query($conn,$empidqry) or die ("FAILED TO CHECK EMP ID ".mysqli_error($conn));
  $empidcount = mysqli_num_rows($empidexecqry);

  if($empidcount!=1){
    $error = true;
    $empiderror = "Employee ID does not exist.";
  }

if (empty($startdate)){

  $error = true;
  $startdateerror = "Please indicate loan start date.";

}

if (empty($enddate)){
  $error = true;
  $enddateerror = "Please indicate loan end date.";

}

if (empty($loanamount)){
  $error = true;
  $loanamounterror = "Please indicate the loan amount.";

}

if(empty($monthlydeductionamount)){
  $error = true;
  $monthlydeductionamounterror = "Please enter the amount to be deducted every month.";

}

if(empty($noofpays)){
  $error = true;
  $paydurationerror = "Please enter number of payment months.";
}

  if (!$error){

    $newdeptqry = "INSERT INTO loans (loanidno,loanorg,loantype, emp_id,empfirstname,emplastname, empmiddlename, start_date,end_date,loan_amount, loan_balance, monthly_deduct,no_of_pays,status, adminname) VALUES ('$loanidno','$loanorg1','$loantype1','$gsisempid','$firstname','$lastname','$middlename','$startdate','$enddate','$loanamount','$loanamount','$monthlydeductionamount','$noofpays','On-Going', '$adminFullName')";
    $newdeptqryresult = mysqli_query($conn,$newdeptqry) or die (" ".mysqli_error($conn));
    // echo $newdeptqry;

    $activityLog = "Added Loan for ($firstname $lastname)";
    $adminActivityQuery = "INSERT INTO adminactivity_log (emp_id, adminname, activity,log_timestamp) VALUES ('$adminId','$adminFullName', '$activityLog', NOW())";
    $adminActivityResult = mysqli_query($conn, $adminActivityQuery);


    $notificationMessage = "Loan has been added for $firstname $lastname";
    $insertNotificationQuery = "INSERT INTO empnotifications (admin_id, adminname, emp_id, message, type, status) VALUES ('$adminId', '$adminFullName','$gsisempid','$notificationMessage','Loan','unread')";
    mysqli_query($conn, $insertNotificationQuery);

    if($newdeptqryresult){

      ?>
   
   <script>
   document.addEventListener('DOMContentLoaded', function() {
       swal({
        //  title: "Good job!",
         text: "Loan inserted successfully",
         icon: "success",
         button: "OK",
        }).then(function() {
           window.location.href = 'adminMasterLoans.php'; // Replace 'your_new_page.php' with the actual URL
       });
   });
</script>
    <?php
 
}
  } else {
    $errType = "danger";
    // $_SESSION['addprofilenotif'] = "Something went wrong. Make sure you accomplish all the required fields.";
    ?><script>
    document.addEventListener('DOMContentLoaded', function() {
        swal({
          // title: "Data ",
          text: "Something went wrong.",
          icon: "error",
          button: "Try Again",
        });
    }); </script>
    <?php
  }

} 

?>

</head>

<style>


textarea {
  max-width: 100%;
  width: 100%;
  height: auto;
  box-sizing: border-box;

}

 .userinfo {
        margin-bottom: 10px;
    }

</style>
<body>

<!--Header-part-->

<?php
INCLUDE ('NAVBARadmin.php');
?>


<div id="content">
    <div class="title d-flex justify-content-center pt-4">
        <h3>ADD LOAN</h3>
       
    </div>

    <div class="nopadding col-6 card shadow mx-auto my-5 p-3 mt-5">

    <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">

    <?php
                $loantypesquery = "SELECT * FROM loantype";
                $loantypesexecqry = mysqli_query($conn, $loantypesquery) or die("FAILED TO EXECUTE LOAN TYPE QUERY " . mysqli_error($conn));
            ?>

        <div class="row">

        <div class="col-lg-4">
        <label class="control-label" for="loantype">Loan Type:</label>
        <select name="loantype" id="loantype" class="form-select" required>
                        <option value=""></option>
                        <?php
                        while ($loantype = mysqli_fetch_array($loantypesexecqry)):
                            $selected = ($loantype['loanorg'] . '|' . $loantype['loantype'] == $_POST['loantype']) ? 'selected' : '';
                        ?>
                            <option value="<?php echo $loantype['loanorg'] . '|' . $loantype['loantype']; ?>" <?php echo $selected; ?>><?php echo $loantype['loantype']; ?></option>
                        <?php endwhile; ?>
                    </select>
        </div>
        <?php
            $lasttypesquery = "SELECT * FROM employees WHERE employment_TYPE ='Permanent'";
            $lasttypesexecqry = mysqli_query($conn, $lasttypesquery) or die("FAILED TO EXECUTE LOAN TYPE QUERY " . mysqli_error($conn));
            ?>

        <div class="col-lg-8 col-md-12">
        <label class="control-label">Last Name:</label>
        <select name="lastname" class="form-select" required>
                        <option></option>
                        <?php
                        while ($lastname = mysqli_fetch_array($lasttypesexecqry)):
                            $selected = ($lastname['last_name'] == $_POST['lastname']) ? 'selected' : '';
                        ?>
                            <option <?php echo $selected; ?>><?php echo $lastname['last_name']; ?></option>
                        <?php endwhile; ?>
                    </select>
        </div>


        </div>
        <div class="button text-center mt-3">
        <button type="submit" class="btn btn-success printbtn" name = "search_btn1">Search</button>

        </div>


    </form>


    <form action="<?php $_SERVER['PHP_SELF'];?>" method="POST">
        
        <div class="row">
            <div class="col-lg-6 col-md-12">
            <label class="control-label">Loan ID Number:</label>
<!-- <input type="text" class="span7" placeholder="SSS ID Number" name="sssidno" value="<?php echo $sssidno;?>"/> -->
<input type="text" class="form-control" placeholder="Loan ID Number" name="loanidno" value="<?php echo $gsis ?? ''; ?>" readonly/>

<!-- <button type="submit" class="btn btn-success printbtn" name = "search_btn">Search</button> -->
<!-- <span class ="label label-important"><?php echo $sssidnumbererror; ?></span> -->

            </div>


            <div class="col-lg-6 col-md-12">
            <label class="control-label">Employee ID:</label>
            <input type="text" class="form-control" placeholder="Employee ID" name="gsisempid" value="<?php echo $gsisempid ?? ''; ?>" readonly/>
                  <!-- <span class ="label label-important"><?php echo $empiderror; ?></span> -->
                </div>

                <div class="col-lg-4 col-md-6">
                <label class="control-label">Last Name:</label>
                <input type="text" class="form-control" placeholder="Last Name" name="last_name" value = "<?php echo $last_name ?? '';?>" readonly/>
                  <!-- <span class ="label label-important"><?php echo $nameerror; ?></span> -->
                </div>

                <div class="col-lg-4 col-md-6">
                <label class="control-label">First Name:</label>
                <input type="text" class="form-control" placeholder="First Name" name="first_name" value = "<?php echo $firstname ?? '';?>" readonly/>
                  <!-- <span class ="label label-important"><?php echo $nameerror; ?></span> -->
                </div>

                <div class="col-lg-4 col-md-6">
                <label class="control-label">Middle Name:</label>
                <input type="text" class="form-control" placeholder="Middle Name" name="middle_name" value = "<?php echo $middlename ?? '';?>" readonly/>
                  <!-- <span class ="label label-important"><?php echo $nameerror; ?></span> -->
                </div>

                <div class="col-lg-6 col-md-12">
                <label class="control-label">Start Date:</label>
                <input type="text" class="form-control datepicker" id="startdatepicker" name ="startpicker" placeholder="Start Date" value=""required >
                  <!-- <span class ="label label-important"><?php echo $startdateerror; ?></span> -->
                </div>

                <div class="col-lg-6 col-md-12">
                <label class="control-label">End Date:</label>
                <input type="text" class="form-control datepicker" id="enddatepicker" name ="endpicker" placeholder="End Date" value="" required>
                  <!-- <span class ="label label-important"><?php echo $enddateerror; ?></span> -->
                    </div>

                    <div class="col-lg-4 col-md-6">
                    <label class="control-label">Monthly Deduction:</label>
                    <input type="text" class="form-control" placeholder="Monthly Deduction Amount" name="monthlydeductionamount" required/>
                  <!-- <span class ="label label-important"><?php echo $monthlydeductionamounterror; ?></span> -->
                    </div>

                    <div class="col-lg-4 col-md-6">
                    <label class="control-label">Loan Amount:</label>
                    <input type="text" class="form-control" placeholder="Loan Amount" name="loanamount" readonly required/>
                  <!-- <span class ="label label-important"><?php echo $loanamounterror; ?></span> -->
                        </div>

                        <div class="col-lg-4 col-md-6">
                        <label class="control-label">Pay Duration:</label>
                        <input type="text" class="form-control" placeholder="" name="payduration" readonly required/>
                  <span> months</span>
                  <!-- <span class ="label label-important"><?php echo $paydurationerror; ?></span> -->
                        </div>
    

        </div>

<div class="button d-flex justify-content-center">
<div class="form-actions">
                <button type="submit" class="btn btn-success" name = "submit_btn" style="float:right;">Submit</button>
              </div>
</div>

    </form>

    </div>


  
  

             
          
        </div>
  
    
   
              
 
<div class="row-fluid">
  <div id="footer" class="span12"> 2023 &copy; WEB-BASED TIMEKEEPING AND PAYROLL SYSTEM USING FINGERPRINT BIOMETRICS</div>
</div>

<?php
unset($_SESSION['anewdept']);
?>

<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $('.datepicker').datepicker({
            format: 'yyyy-mm-dd',
            autoclose: true
        });
    });
</script>
<script>
  $(document).ready(function() {
    // Assuming date format is yyyy mm dd
    $("#enddatepicker, #startdatepicker").on("change", function() {
      var startDate = $("#startdatepicker").val();
      var endDate = $("#enddatepicker").val();

      if (startDate && endDate) {
        var start = new Date(startDate);
        var end = new Date(endDate);

        var monthDiff = (end.getFullYear() - start.getFullYear()) * 12 + end.getMonth() - start.getMonth();

        $("input[name='payduration']").val(monthDiff);
      }
    });
  });
</script>
<script>
  $(document).ready(function() {
    // Assuming date format is yyyy mm dd
    $("#enddatepicker, #startdatepicker, input[name='monthlydeductionamount'], input[name='payduration']").on("change", function() {
      var startDate = $("#startdatepicker").val();
      var endDate = $("#enddatepicker").val();
      var monthlyDeduction = parseFloat($("input[name='monthlydeductionamount']").val());
      var payDuration = parseInt($("input[name='payduration']").val());

      if (startDate && endDate && !isNaN(monthlyDeduction) && !isNaN(payDuration)) {
        var start = new Date(startDate);
        var end = new Date(endDate);

        var monthDiff = (end.getFullYear() - start.getFullYear()) * 12 + end.getMonth() - start.getMonth();

        var loanAmount = monthlyDeduction * monthDiff;

        $("input[name='loanamount']").val(loanAmount.toFixed(2));
      }
    });
  });
</script>

</body>
</html>

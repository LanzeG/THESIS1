<?php
include("../DBCONFIG.PHP");
include("../LoginControl.php");
include("../BASICLOGININFO.PHP");
$query = "SELECT * FROM notifications";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Home</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
</head>
<body>

<!--Header-part-->
<?php
INCLUDE ('NAVBARadmin.php');
?>

<div id="content">
    <div class="title d-flex justify-content-center pt-3">
        <h3>ALL NOTIFICATIONS</h3>
    </div>
    <hr>
    <br>
    <div class="container p-5">
        <div class="">
            <table class="table table-striped table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>Notifications</th>
                        <!-- Add more columns as needed -->
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Loop through the notifications and display them in the table rows
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        if ($row['type'] == 'Overtime') {
                            echo "<td><a href='adminOT.php'>{$row['message']}</a></td>";
                        } 
                        elseif ($row['type'] == 'Leave') {
                            echo "<td><a href='adminLEAVES.php'>{$row['message']}</a></td>";
                        }
                        elseif ($row['type'] == 'Issue') {
                            echo "<td><a href='adminFeedback.php?notification_id={$row['notification_id']}'>{$row['message']}</a></td>";
                           
                        }
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <hr>
</div>

</body>
</html>



<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin Home</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<!-- <link rel="stylesheet" href="../css/bootstrap.min.css" /> -->
<link rel="stylesheet" href="../css/bootstrap-responsive.min.css" />
<!-- <link rel="stylesheet" href="../css/fullcalendar.css" />
<link rel="stylesheet" href="../css/maruti-style.css" /> -->
<link rel="stylesheet" href="../css/maruti-media.css" class="skin-color" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker@3.1.0/daterangepicker.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/daterangepicker@3.1.0/daterangepicker.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>


<?php
include("../DBCONFIG.PHP");
include("../LoginControl.php");
include("../BASICLOGININFO.PHP");

$adminId = $_SESSION['adminId'];

// Pagination setup
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$recordsPerPage = 10; // You can adjust this number based on your preference

$startFrom = ($page - 1) * $recordsPerPage;

// Query for fetching paginated records
$query = "SELECT * FROM adminactivity_log ORDER BY emp_id DESC LIMIT $startFrom, $recordsPerPage";
$result = mysqli_query($conn, $query);

// Query to get total number of records
$countQuery = "SELECT COUNT(*) as total FROM adminactivity_log";
$countResult = mysqli_query($conn, $countQuery);
$countRow = mysqli_fetch_assoc($countResult);
$totalRecords = $countRow['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Head content here -->
</head>
<body>

<!-- Header and navigation -->
<?php
include('NAVBARadmin.php');
?>

<div id="content">
<div class="title d-flex justify-content-center pt-3">
      <h3>
      ACTIVITY LOGS
      </h3>
    </div>
<hr>
<br>
                    <!-- Activity Logs widget box -->
          

                        <div class="row mt-3 mb-1 d-flex justify-content-end">
    <div class="table d-flex align-items-center table-responsive ">
<table class="table table-striped table-bordered ">
<thead class="table-dark">
            <tr>
                <th>LOG ID</th>
                <th>Employee ID</th>
                <th>Employee Name</th>
                <th>Activity</th>
                <th>Timestamp</th>
                <!-- Add more columns as needed -->
            </tr>
        </thead>
        <tbody>
            <?php
            // Loop through the paginated records and display them in the table rows
            while ($row1 = mysqli_fetch_array($result)) {
            ?>
                <tr class="gradeX">
                    <td class=col-1><?php echo $row1['log_id']; ?></td>
                    <td class=col-2><?php echo $row1['emp_id']; ?></td>
                    <td class=col-2><?php echo $row1['adminname']; ?></td>
                    <td class="activity-column"><?php echo $row1['activity']; ?></td>
                    <td class="col-2"><?php echo $row1['log_timestamp']; ?></td>
                </tr>
            <?php
            }
            ?>
        </tbody>
        
    </table>
</div>
</div>
<div class="pagination">
                    <?php
    $totalPages = ceil($totalRecords / $recordsPerPage);
    
    $currentPage = isset($_GET['page']) ? max(1, min($_GET['page'], $totalPages)) : 1;
    $pageRange = 2; 

    
    function generatePageLink($pageNumber, $text = null) {
        $text = $text ?? $pageNumber; 
        $url = "adminActivitylogs.php?page=$pageNumber";
        return "<a href='$url'>$text</a>";
    }

    
    if ($currentPage - $pageRange > 2) {
        echo generatePageLink(1) . " ... ";
    }

   
    for ($i = max(1, $currentPage - $pageRange); $i <= min($totalPages, $currentPage + $pageRange); $i++) {
        echo generatePageLink($i);

        if ($i < min($totalPages, $currentPage + $pageRange)) {
            echo "";
        }
    }

    if ($currentPage + $pageRange < $totalPages - 1) {
        echo " ... " . generatePageLink($totalPages);
    }
    ?>
    
                  
                </div>
                <hr>
            </div>

                    <!-- Pagination links -->
                    
            <style>
    .pagination {
        display: flex;
        justify-content: left;
        margin-top: 20px;
        font-family: 'Arial', sans-serif;
        color: #ffff; 
    }

    .pagination a, .pagination span {
        padding: 10px;
        margin: 0 5px;
        text-decoration: none;
        color: #000000;
        background-color: #ffff; 
        border: 1px solid #000000;
        border-radius: 4px;
        transition: background-color 0.3s ease, color 0.3s ease;
    }

    .pagination a:hover {
        background-color: #ffffff;
        color: #000000;
    }

    .pagination a.active {
        background-color: #49cced;
        color: #fff;
        cursor: default;
    }

    .pagination span.ellipsis {
        margin: 0 5px;
        color: #555;
    }

        table {
            width: 100%;
            max-width: 100%;
        }

        td.activity-column {
            max-width: 100px; 
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        @media (min-width: 576px) {
            table {
                width: 80%;
            }
        }

        @media (min-width: 768px) {
            table {
                width: 70%;
            }
        }

        @media (min-width: 992px) {
            table {
                width: 60%;
            }
        }

        @media (min-width: 1200px) {
            table {
                width: 50%;
            }
        }
    </style>
</div>
</body>
</html>



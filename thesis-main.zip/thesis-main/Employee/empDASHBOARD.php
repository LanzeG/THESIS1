<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<?php
include("../DBCONFIG.PHP");
include("../LoginControl.php");
include("../BASICLOGININFO.PHP");

session_start();

$uname = $_SESSION['uname'];
$empid = $_SESSION['empId'];


$getinfoqry = "SELECT * from employees WHERE user_name = '$uname'";
$getinfoexecqry = mysqli_query($conn,$getinfoqry) or die ("FAILED TO GET INFORMATION ".mysqli_error($conn));
$getinfoarray = mysqli_fetch_array($getinfoexecqry);
$getinforows = mysqli_num_rows($getinfoexecqry);
if ($getinfoarray && $getinforows !=0){

 $currprefixid = $getinfoarray['prefix_ID'];
 $currempid = $getinfoarray['emp_id'];
        //$currcardnumber = $getinfoarray['card_number'];
        $currfingerprintid = $getinfoarray['fingerprint_id'];
        $currusername = $getinfoarray['user_name'];
        $currlastname = $getinfoarray['last_name'];
        $currfirstname = $getinfoarray['first_name'];
        $currmiddlename = $getinfoarray['middle_name'];
        $currdateofbirth = $getinfoarray['date_of_birth'];
        $currposition = $getinfoarray['position'];
        $curremptype = $getinfoarray['employment_TYPE'];
        $curraddress = $getinfoarray['emp_address'];
        $currnationality = $getinfoarray['emp_nationality'];
        $currdeptname = $getinfoarray['dept_NAME'];
        $currshiftsched = $getinfoarray['shift_SCHEDULE'];
        $currcontact = $getinfoarray['contact_number'];
        $currdatehired = $getinfoarray['date_hired'];
        $currdateregularized = $getinfoarray['date_regularized'];
        $currdateresigned = $getinfoarray['date_resigned'];
        $currimg = $getinfoarray['img_tmp'];
$_SESSION['empID'] = $currempid;
}

$customQuery = "SELECT position.position_name, salarygrade.salarygrade
               FROM position
               JOIN salarygrade ON position.salarygrade = salarygrade.salarygrade
               WHERE position.position_name = '$currposition'";

// Execute the query
$customQueryResult = mysqli_query($conn, $customQuery) or die("FAILED TO GET INFORMATION " . mysqli_error($conn));
// Fetch the result
if (mysqli_num_rows($customQueryResult) > 0) {
  // Fetch the result
  $row = mysqli_fetch_assoc($customQueryResult);

  // Now you can use $row to access the data
  $positionName = $row['position_name'];
  $salaryGrade = $row['salarygrade'];

  // Do something with the data
  // echo "Position Name: $positionName, Salary Grade: $salaryGrade";
} else {
  // No result found
  $salaryGrade ='';
}




//  if ($_SERVER["REQUEST_METHOD"] == "POST") {
     if (isset($_POST['pperiod_btn1'])) {
         // Handle the case for the first "Go" button (redirect to empaction.php)
         $payfunction = $_POST['payfunction'];
        $payperiod = $_POST['payperiod'];
        $_SESSION['payperiods'] = $_POST['payperiod'];
        $_SESSION['payfunction'] = $_POST['payfunction'];

        // Redirect to empaction.php with the form data
        echo '<script>';
        echo 'var url = "empaction.php?payfunction=' . urlencode($payfunction) . '&payperiod=' . urlencode($payperiod) . '";';
        echo 'window.open(url, "_blank");';
        echo '</script>';

     } elseif (isset($_POST['pperiod_btn'])){

      $payperiod = $_POST['payperiod'];
      $_SESSION['payperiods'] = $_POST['payperiod'];
      $searchquery = "SELECT * FROM employees, PAY_PER_PERIOD WHERE employees.emp_id = PAY_PER_PERIOD.emp_id AND PAY_PER_PERIOD.emp_id = '$empid' AND PAY_PER_PERIOD.pperiod_range = '$payperiod' ORDER BY pperiod_range";
      $search_result = filterTable($searchquery);

      

    }  else  {
      $searchquery = "SELECT * from employees, PAY_PER_PERIOD WHERE employees.emp_id = PAY_PER_PERIOD.emp_id AND PAY_PER_PERIOD.emp_id = '$empid' ORDER BY PAY_PER_PERIOD.pperiod_range ";  
      $search_result = filterTable($searchquery);
      // $_SESSION['payperiods'] = 'noset';
      }
      if (isset($payperiod)) {
        $query = "SELECT * FROM payperiods WHERE pperiod_range = '$payperiod'";
        $result = mysqli_query($conn, $query);
        
       
        if ($result) {
          // Fetch the data from the result set
          $data = mysqli_fetch_assoc($result);
          $period_start = isset($data['pperiod_start']) ? $data['pperiod_start'] : null;
          $period_end = isset($data['pperiod_end']) ? $data['pperiod_end'] : null;
       
          $dateTime = new DateTime($period_start);
          $month = $dateTime->format('F'); // Full month name (e.g., January)
          $year = $dateTime->format('Y');  // 4-digit year (e.g., 2024)
       }
       
       $printquery = "SELECT * FROM DTR, employees WHERE DTR.emp_id = employees.emp_id and DTR.emp_id = '$empid' AND DTR.DTR_day BETWEEN '$period_start' and '$period_end' ORDER BY DTR_day ASC";
       $printqueryexec = mysqli_query($conn,$printquery);
       $printarray = mysqli_fetch_array($printqueryexec);
       $d = strtotime("now");
              $currtime = date ("Y-m-d H:i:s", $d);
       // $payperiod = $_SESSION['payperiodrange'];
       
       
       
       if ($printarray){
       
        $prefix = $printarray['prefix_ID'];
        $idno = $printarray['emp_id'];
        $lname = $printarray['last_name'];
        $fname = $printarray['first_name'];
        $mname = $printarray['middle_name'];
        $dept = $printarray['dept_NAME'];
        $position = $printarray['position'];
       
        $name = "$lname, $fname $mname";
        $empID = "$prefix$idno";
       }
       
       
       $payperiodval = "SELECT DTR.*,(TIME_KEEPING.hours_work+TIME_KEEPING.overtime_hours) as totalhours,TIME_KEEPING.hours_work,TIME_KEEPING.overtime_hours FROM DTR INNER JOIN TIME_KEEPING ON TIME_KEEPING.emp_id=DTR.emp_id AND TIME_KEEPING.timekeep_day=DTR.DTR_day WHERE DTR.emp_id = '$empid' AND DTR_day BETWEEN '$period_start' AND '$period_end' ORDER BY DTR_day ASC";
       $payperiodexec = mysqli_query($conn,$payperiodval) or die ("FAILED TO QUERY TIMEKEEP DETAILS ".mysqli_error($conn));
       
       $totalot = "SELECT SUM(undertime_hours) as totalUT, SUM(overtime_hours) as totalOT, SUM(hours_work) as totalWORKhours, SUM(late_hours) as totalLATEhours, SUM((hours_work+overtime_hours)-late_hours) as totalness FROM TIME_KEEPING WHERE emp_id = '$empid' AND timekeep_day BETWEEN '$period_start' and '$period_end' ORDER BY timekeep_day ASC";
       $totalotexec =mysqli_query($conn,$totalot) or die ("OT ERROR ".mysqli_error($conn));
       $totalotres = mysqli_fetch_array($totalotexec);
       
         $searchquery = "SELECT * from employees, PAY_PER_PERIOD WHERE employees.emp_id = PAY_PER_PERIOD.emp_id AND PAY_PER_PERIOD.emp_id = '$empid' ORDER BY PAY_PER_PERIOD.pperiod_range ";  
         $search_result = filterTable($searchquery);
         // $_SESSION['payperiods'] = 'noset';
       
       
       
         //for late and undertime bc i like it redundant
         $attquery = "SELECT
         emp_id,
         SUM(CASE WHEN in_morning > 0 THEN 1 ELSE 0 END) AS TOTAL_ATTENDANCE,
         SUM(CASE WHEN late_hours > 0 THEN 1 ELSE 0 END) AS TOTAL_LATE_HOURS,
         SUM(CASE WHEN undertime_hours > 0 THEN 1 ELSE 0 END) AS TOTAL_UNDERTIME_HOURS
       FROM
         time_keeping
       WHERE
         emp_id = $empid
         AND timekeep_day BETWEEN '$period_start' AND '$period_end'
       GROUP BY
         emp_id";
        
        $resultattquery = mysqli_query($conn, $attquery) or die(mysqli_error($conn));
        $rowattquery = mysqli_fetch_assoc($resultattquery);
       }
//  }  else{
//   $_SESSION['payperiods'] = 'noset';
//  }
 
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Employee Home</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="../css/bootstrap.min.css" />
<link rel="stylesheet" href="../css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="../css/fullcalendar.css" />
<link rel="stylesheet" href="../css/maruti-style.css" />
<link rel="stylesheet" href="../css/maruti-media.css" class="skin-color" />
<link rel="stylesheet" href="../jquery-ui-1.12.1/jquery-ui.css">
<link rel="stylesheet" href="timeline.css">
<!-- Chartist.js -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/chartist@0.11.4/dist/chartist.min.css">
<script src="https://cdn.jsdelivr.net/npm/chartist@0.11.4/dist/chartist.min.js"></script>

<script src="../jquery-ui-1.12.1/jquery-3.2.1.js"></script>
<script src="../jquery-ui-1.12.1/jquery-ui.js"></script>

<script type ="text/javascript">
  $( function() {
      $( "#datepickerfrom" ).datepicker({ dateFormat: 'yy-mm-dd'});
      } );
  $( function() {
      $( "#datepickerto" ).datepicker({ dateFormat: 'yy-mm-dd'});
      } );
  
</script>
</head>
<body>

<!--Header-part-->

<?php
INCLUDE ('empNAVBAR.php');
?>


 <div id="content-header">
    <div id="breadcrumb"> <a href="empDASHBOARD.php" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a>
      <a href="../try.php" title="Employee Info" class="tip-bottom"><i class="icon-user"></i> My Profile</a>
    </div>
  </div>

  <!-- START OF CONTENT -->
<!-- <div class="content1">
  <div class="container-lg">

  <div class="d-flex justify-content-center align-items-center">
      <h3 style="text-align: center;">Employee Information</h3>

    </div>
    
    <div class="widget-box">
          <div class="widget-title">
            
            <ul class="nav nav-tabs" id="myTab">
              
              <li class="active"><a href="empDASHBOARD.php"><i class="icon-user"></i> Profile</a></li>
              <li><a href="empAPPLYOvertime.php"><i class="icon-time"></i> Overtime</a></li>
              <li><a href="empAPPLYLeave.php"><i class="icon-calendar"></i> Leave</a></li>
              <li><a href="empATTENDANCErecords.php"><i class="icon-th"></i> My Records</a></li>
              <li><a href="empActivitylogs.php"><i class="icon-time"></i> Activity Logs</a></li>
              <li class=""><a href="empLoans.php"><i class="icon-file"></i> Loans</a></li>
              

              
            </ul>
          </div>
    </div>


  </div>
</div> -->


<div id="content">

 
<!-- START OF CONT-FLUID -->
  <div class="container-fluid">
    <!-- START OF ROW -->
    
    
      <div class="d-flex justify-content-center align-items-center mb-0">
      <h3 style="text-align: center;">Employee Information</h3>

    </div>
    


    <div class ="row-fluid">
     
        <div class="widget-box col-12">
          <div class="widget-title">
            <ul class="nav nav-tabs" id="myTab">
              
              <li class="active"><a href="empDASHBOARD.php"><i class="icon-user"></i> Profile</a></li>
              <li><a href="empAPPLYOvertime.php"><i class="icon-time"></i> Overtime</a></li>
              <li><a href="empAPPLYLeave.php"><i class="icon-calendar"></i> Leave</a></li>
              <li><a href="empATTENDANCErecords.php"><i class="icon-th"></i> My Records</a></li>
              <li><a href="empActivitylogs.php"><i class="icon-time"></i> Activity Logs</a></li>
              <li class=""><a href="empLoans.php"><i class="icon-file"></i> Loans</a></li>
              

              
            </ul>
          </div>
        <div class="d-flex flex-row flex-container allcontent flex-wrap m-1 mt-4">
          <div class="row">

            <div class="row">
            <div class="card">
          <div class="card__img">
    <svg xmlns="http://www.w3.org/2000/svg" width="100%">
        <rect fill="#87CEEB" width="540" height="450"></rect>
        <defs>
            <linearGradient id="a" gradientUnits="userSpaceOnUse" x1="0" x2="0" y1="0" y2="100%" gradientTransform="rotate(222,648,379)">
                <stop offset="0" stop-color="#87CEEB"></stop>
                <stop offset="1" stop-color="#00BFFF"></stop>
            </linearGradient>
            <pattern patternUnits="userSpaceOnUse" id="b" width="300" height="250" x="0" y="0" viewBox="0 0 1080 900">
                <g fill-opacity="0.5">
                    <polygon fill="#87CEEB" points="90 150 0 300 180 300"></polygon>
                    <polygon points="90 150 180 0 0 0"></polygon>
                    <polygon fill="#ADD8E6" points="270 150 360 0 180 0"></polygon>
                    <polygon fill="#B0E0E6" points="450 150 360 300 540 300"></polygon>
                    <polygon fill="#87CEEB" points="450 150 540 0 360 0"></polygon>
                    <polygon points="630 150 540 300 720 300"></polygon>
                    <polygon fill="#B0E0E6" points="630 150 720 0 540 0"></polygon>
                    <polygon fill="#87CEEB" points="810 150 720 300 900 300"></polygon>
                    <polygon fill="#FFFFFF" points="810 150 900 0 720 0"></polygon>
                    <polygon fill="#B0E0E6" points="990 150 900 300 1080 300"></polygon>
                    <polygon fill="#87CEEB" points="990 150 1080 0 900 0"></polygon>
                    <polygon fill="#B0E0E6" points="90 450 0 600 180 600"></polygon>
                    <polygon points="90 450 180 300 0 300"></polygon>
                    <polygon fill="#666" points="270 450 180 600 360 600"></polygon>
                    <polygon fill="#ADD8E6" points="270 450 360 300 180 300"></polygon>
                    <polygon fill="#B0E0E6" points="450 450 360 600 540 600"></polygon>
                    <polygon fill="#999" points="450 450 540 300 360 300"></polygon>
                    <polygon fill="#999" points="630 450 540 600 720 600"></polygon>
                    <polygon fill="#FFFFFF" points="630 450 720 300 540 300"></polygon>
                    <polygon points="810 450 720 600 900 600"></polygon>
                    <polygon fill="#B0E0E6" points="810 450 900 300 720 300"></polygon>
                    <polygon fill="#ADD8E6" points="990 450 900 600 1080 600"></polygon>
                    <polygon fill="#87CEEB" points="990 450 1080 300 900 300"></polygon>
                    <polygon fill="#4682B4" points="90 750 0 900 180 900"></polygon>
                    <polygon points="270 750 180 900 360 900"></polygon>
                    <polygon fill="#B0E0E6" points="270 750 360 600 180 600"></polygon>
                    <polygon points="450 750 540 600 360 600"></polygon>
                    <polygon points="630 750 540 900 720 900"></polygon>
                    <polygon fill="#87CEEB" points="630 750 720 600 540 600"></polygon>
                    <polygon fill="#ADD8E6" points="810 750 720 900 900 900"></polygon>
                    <polygon fill="#666" points="810 750 900 600 720 600"></polygon>
                    <polygon fill="#999" points="990 750 900 900 1080 900"></polygon>
                    <polygon fill="#999" points="180 0 90 150 270 150"></polygon>
                    <polygon fill="#B0E0E6" points="360 0 270 150 450 150"></polygon>
                    <polygon fill="#FFFFFF" points="540 0 450 150 630 150"></polygon>
                    <polygon points="900 0 810 150 990 150"></polygon>
                    <polygon fill="#4682B4" points="0 300 -90 450 90 450"></polygon>
                    <polygon fill="#FFFFFF" points="0 300 90 150 -90 150"></polygon>
                    <polygon fill="#FFFFFF" points="180 300 90 450 270 450"></polygon>
                    <polygon fill="#666" points="180 300 270 150 90 150"></polygon>
                    <polygon fill="#4682B4" points="360 300 270 450 450 450"></polygon>
                    <polygon fill="#FFFFFF" points="360 300 450 150 270 150"></polygon>
                    <polygon fill="#87CEEB" points="540 300 450 450 630 450"></polygon>
                    <polygon fill="#4682B4" points="540 300 630 150 450 150"></polygon>
                    <polygon fill="#ADD8E6" points="720 300 630 450 810 450"></polygon>
                    <polygon fill="#666" points="720 300 810 150 630 150"></polygon>
                    <polygon fill="#FFFFFF" points="900 300 810 450 990 450"></polygon>
                    <polygon fill="#999" points="900 300 990 150 810 150"></polygon>
                    <polygon points="0 600 -90 750 90 750"></polygon>
                    <polygon fill="#666" points="0 600 90 450 -90 450"></polygon>
                    <polygon fill="#ADD8E6" points="180 600 90 750 270 750"></polygon>
                    <polygon fill="#4682B4" points="180 600 270 450 90 450"></polygon>
                    <polygon fill="#4682B4" points="360 600 270 750 450 750"></polygon>
                    <polygon fill="#999" points="360 600 450 450 270 450"></polygon>
                    <polygon fill="#666" points="540 600 630 450 450 450"></polygon>
                    <polygon fill="#87CEEB" points="720 600 630 750 810 750"></polygon>
                    <polygon fill="#FFFFFF" points="900 600 810 750 990 750"></polygon>
                    <polygon fill="#87CEEB" points="900 600 990 450 810 450"></polygon>
                    <polygon fill="#B0E0E6" points="1080 300 990 450 1170 450"></polygon>
                    <polygon fill="#FFFFFF" points="1080 300 1170 150 990 150"></polygon>
                    <polygon points="1080 600 990 750 1170 750"></polygon>
                    <polygon fill="#666" points="1080 600 1170 450 990 450"></polygon>
                    <polygon fill="#DDD" points="1080 900 1170 750 990 750"></polygon>
                </g>
            </pattern>
        </defs>
        <rect x="0" y="0" fill="url(#a)" width="100%" height="100%"></rect>
        <rect x="0" y="0" fill="url(#b)" width="100%" height="100%"></rect>
    </svg>
</div>

<div class="card__avatar">
    <img height="100" width="157" src="data:image;base64,<?php echo $currimg?>" style="border-radius: 30%;">
</div>
<div class="textContainer">
    <p class="name"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
  <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/>
  <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"/>
</svg> <i class="bi bi-person-fill"><?php $fullName = implode(' ', [$currfirstname, $currlastname]);
    echo $fullName; ?></i></p>
    <p class="empID">Employee ID: <i><?php echo $currempid; ?></i></p>
    <p class="position">Position: <i><?php echo $currposition; ?></i></p>
    <p class="department">Department: <i><?php echo $currdeptname; ?></i></p>
    <p class="salgrade">Salary Grade: <i><?php echo $salaryGrade;?></i></p>
    <p class="empstatus">Employment Status: <?php echo $curremptype; ?></p>
    
   
  </div>
  <div class="buttons">
  <div class = "uinfotab2"><a href ="empCHANGEPASSWORD.php" class = "btn btn-info"><span class="icon"><i class="icon-edit"></i> </span>Change Password</a></div>
  </div>

<style>
  .textContainer {
  width: 100%;
  text-align: left;
  padding: 20px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.name {
  font-size: 1.2em;
  font-weight: 600;
  margin-top: 50px;
  color: black;
  letter-spacing: 0.5px;
}

.position {
  font-size: 1em;
  color: black;
  letter-spacing: 0.2px;
}
.department {
  font-size: 1em;
  color: black;
  letter-spacing: 0.2px;
}
.empstatus {
  font-size: 1em;
  color: black;
  letter-spacing: 0.2px;
}
.salgrade {
  font-size: 1em;
  color: black;
  letter-spacing: 0.2px;
}
.empID {
  font-size: 1em;
  color: black;
  letter-spacing: 0.2px;
}


</style>

    <!-- <div class="card__title"><?php echo $currfirstname; ?></div>
    <div class="card__subtitle"><?php echo $currdeptname; ?></div>
    <div class="card__subtitle1"><?php echo $currdeptname; ?></div>
    <div class="card__subtitle2"><?php echo $currdeptname; ?></div>
    <div class="card__subtitle3"><?php echo $currdeptname; ?></div> 
    <div class="card__wrapper">
    </div>
      <span class = "uinfotab2"><a href ="empCHANGEPASSWORD.php" class = "btn btn-info"><span class="icon"><i class="icon-edit"></i> </span>Change Password</a></span> -->
        
    </div>
            </div>
            <!-- <div class="col-3">
              dfsf
            </div>
            <div class="col-3">
              dfsf
            </div>
            <div class="col-3">
              dfsf
            </div>
          </div> -->

       
    <!-- start ng info 2 -->
    <div class="col-3 bg-light">
  <div>
  <ul class="timeline">
    <li style="--accent-color:#41516C">
    <div class="date">Date Hired</div>
    <div class="text mt-2 ml-2">
    <p><?php echo $currdatehired;?></p>
       <p><?php echo $currposition;?></p>
    </div>
    </li>
  <?php
  if ($currdateregularized != '0000-00-00' && $currdateregularized !='') 
  {?>
    <li style="--accent-color:#FBCA3E">
    <div class="date">Date Regularized</div>
    <div class="text mt-2 ml-2">
    <p><?php echo $currdateregularized;?></p>
       <p><?php echo $currposition;?></p>
    </div>
        
    </li>
<?php


  }
  if ($currdateresigned != '0000-00-00' && $currdateresigned !='') 
  {?>
    <li style="--accent-color:#E24A68">
    <div class="date">Date Resigned</div>
    <div class="text mt-2 ml-2">
    <p><?php echo $currdateregularized;?></p>
       <p>Resigned</p>
    </div>
        
    </li>
<?php


  }
  ?>
    <!-- 
    
   
    <li style="--accent-color:#1B5F8C">
    <div class="date">promoted</div>
    <div class="text mt-2 ml-2">
    <p>asdfasdf</p>
       <p>asdfasdf</p>
    </div>
    </li>
    <li style="--accent-color:#1B5F8C">
        <div class="date">promoted</div>
        <p>asdfasdf</p>
       <p>asdfasdf</p>
    </li> -->
</ul>
  </div>
    </div>
    <!-- <div class="youare">
      <div class="pls">
     <ul class="timeline">
    <li style="--accent-color:#41516C">
        <div class="date">2012</div>
        <div class="title">Hired</div>
        <div class="descr">Lorem ipsum, dolor sit amet consectetur adipisicing elit.</div>
    </li>
    <li style="--accent-color:#FBCA3E">
        <div class="date">2014</div>
        <div class="title">Promoted</div>
        <div class="descr">Lorem ipsum dolor sit, amet consectetur adipisicing elit. </div>
    </li>
    <li style="--accent-color:#E24A68">
        <div class="date">2015</div>
        <div class="title">Promoted</div>
        <div class="descr">Lorem ipsum dolor sit amet consectetur adipisicing elit</div>
    </li>
    <li style="--accent-color:#1B5F8C">
        <div class="date">2018</div>
        <div class="title">Promoted</div>
        <div class="descr">Lorem ipsum dolor, </div>
    </li>
    <li style="--accent-color:#4CADAD">
        <div class="date">2022</div>
        <div class="title">Promoted</div>
        <div class="descr">Lorem, ipsum dolor sit .</div>
    </li>
</ul>

</div>
</div> -->

            <!-- <div class="col-3">
              dfsf
            </div>
            <div class="col-3">
              dfsf
            </div>
            <div class="col-3">
              dfsf
            </div>
          </div> -->

       
    <!-- start ng info 2 -->

          <!-- end of info 2 -->

          <!-- start of chart -->


         
  <div class="chart-container col-3">
  <canvas id="myPieChart" width="280" height="280"></canvas>
  <div class="container-fluid">      
    <div class = "row-fluid">
    <div class = "span5">
            <div class ="control-group">
              <form action="" method ="post">
              <label class="control-label">Select Function:</label>
              <div class="controls">
              <select name="payfunction" style="margin-bottom: 20px;">
              <option value="Generate Payslip" <?php echo (isset($_SESSION['payfunction']) && $_SESSION['payfunction'] == 'Generate Payslip') ? 'selected' : ''; ?>>Generate Payslip</option>Generate Payslip</option>
              <option value="View DTR" <?php echo (isset($_SESSION['payfunction']) && $_SESSION['payfunction'] == 'View DTR') ? 'selected' : ''; ?>>View DTR</option>
              <option value="View Timesheet" <?php echo (isset($_SESSION['payfunction']) && $_SESSION['payfunction'] == 'View Timesheet') ? 'selected' : ''; ?>>View Timesheet</option>
              <option value="View Leaves" <?php echo (isset($_SESSION['payfunction']) && $_SESSION['payfunction'] == 'View Leaves') ? 'selected' : ''; ?>>View Leaves</option>
          </select> 
                  <button type="submit" class="btn btn-success printbtn" name="pperiod_btn1" style="margin-bottom: 20px;" >Go</button>
              </div>
                   
                    <style>
                    .controls {
                        display: flex;
                        align-items: center;
                    }

                    .controls select {
                        margin-bottom: 10px;
                        margin-right: 10px; /* Adjust the margin as needed */
                    }
                  </style>

<!-- <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post"> -->
    <?php
    $payperiodsquery = "SELECT * FROM payperiods";
    $payperiodsexecquery = mysqli_query($conn, $payperiodsquery) or die ("FAILED TO EXECUTE PAYPERIOD QUERY " . mysqli_error($conn));
    ?>
    <label class="control-label">Select Payroll Period:</label>
    <div class="controls">
        <select name="payperiod" style="margin-bottom: 20px;" required>
            <option value=""></option>
            <?php  // Iterate through pay periods
            while ($payperiodchoice = mysqli_fetch_array($payperiodsexecquery)):
                $selected = ($payperiodchoice['pperiod_range'] == $_SESSION['payperiods']) ? 'selected' : '';
                ?>
                <option value="<?php echo $payperiodchoice['pperiod_range']; ?>" <?php echo $selected; ?>>
                    <?php echo $payperiodchoice['pperiod_range']; ?>
                </option>
            <?php endwhile; ?>
        </select>
        <button type="submit" class="btn btn-success printbtn" name="pperiod_btn" style="margin-bottom: 20px;" >Go</button>
    </div>
</form>

                <!-- <a href="printpayslip.php" class="btn btn-success" role="button" target="_blank">Generate Payslip</a>
                <a href="printdtr.php" class="btn btn-success" role="button" target="_blank">View DTR</a>-->
                <!-- <a href="printtimesheet.php" class="btn btn-success" role="button" target="_blank">View Timesheet</a> -->
                <!-- <a href="printleaves.php" class="btn btn-success" role="button" target="_blank">Apply for Leave</a> -->
                <div class="buttons2 d-flex justify-content-center align-items-center">
                <div class = "uinfotab3"><a href ="empDASHBOARD.php" class = "btn btn-success"><span class="icon"><i class="icon-refresh"></i></span> Refresh</a></div>
                
                </div>
                <!-- <small><?php echo $attrecordview; ?></small> -->
              </div>
              <!-- row fluid -->
          </div>
   
    </div>
  </div>
  </div>

    <div class="information col-3">
    <div class="container">
 
 <div class="cards-container">
   <div class="sibbmpresidenteko large-card">
    
     <div class = "widget-title"><span class="icon"><i class ="icon-user"></i></span>
           <h5> Total Attendance </h5></div>
           <span class = "span6">
           <h6 style="margin-top: 20px;">You have <?php echo isset($rowattquery['TOTAL_ATTENDANCE']) ? $rowattquery['TOTAL_ATTENDANCE'] : 0; ?> Attendance</h6>
            <!-- <h5>"number, Attendance"</h5> -->
            
           </span>
           <span class = "span6">
             
        

   
  
     <div class="voice-chat-card-body">
     
     </div>
   </div>
   <div class="sibbmpresidenteko large-card">
   <div class = "widget-title"><span class="icon"><i class ="icon-user"></i></span>
           <h5> Total Late </h5></div>
           <span class = "span6">
           <h6 style="margin-top: 20px;">You have <?php echo isset($rowattquery['TOTAL_LATE_HOURS']) ? $rowattquery['TOTAL_LATE_HOURS'] : 0; ?> Late</h6>
            <!-- <h5>"number, LATE"</h5> -->
           </span>
           <span class = "span6">
     <div class="voice-chat-card-body">
       <!-- Content for Card 1 goes here -->
     </div>
   </div>
   <div class="sibbmpresidenteko large-card">
     <div class = "widget-title"><span class="icon"><i class ="icon-user"></i></span>
           <h5> Total Undertime </h5></div>
           <span class = "span6">
           <h6 style="margin-top: 20px;">You have <?php echo isset($rowattquery['TOTAL_UNDERTIME_HOURS']) ? $rowattquery['TOTAL_UNDERTIME_HOURS'] : 0; ?> Undertime</h6>
            <!-- <h5>"number, UNDERTIME"</h5> -->
           </span>
           <span class = "span6">
     <div class="voice-chat-card-body">
       <!-- Content for Card 2 goes here -->
     </div>
   </div>
 </div>
      </div>
      <div class="widget-content no-padding">
  <div class="table-responsive">
    <table class="table table-bordered data-table">
      <thead>
        <tr>
          <th>DATE</th>
          <th>IN</th>
          <th>OUT</th>
          <th>Reg. Hours</th>
          <th></th>
          <th>IN</th>
          <th>OUT</th>
          <th>OT Hours</th>
          <th>Daily Total</th>                 
        </tr>
      </thead>
      <tbody>
        <?php
        if(isset($payperiodexec)){
    while ($payperiodarray = mysqli_fetch_array($payperiodexec)) {
        $dtrday = $payperiodarray['DTR_day'];
        $day = date('d', strtotime($dtrday));
        $hrswrk = $payperiodarray['hours_work'];
        $overtimeinout = "SELECT * FROM OVER_TIME WHERE emp_id = '$empid' and ot_day = '$dtrday' and ot_remarks ='Approved'";
        $overtimeinoutexec = mysqli_query($conn, $overtimeinout) or die ("FAILED TO EXECUTE OT QUERY " . mysqli_error($conn));
        $overtimearray = mysqli_fetch_array($overtimeinoutexec);

        if ($overtimearray) {
            $otin = $overtimearray['ot_time'];
            $otout = $overtimearray['ot_timeout'];
        } else {
            $otin = "";
            $otout = "";
        }
        ?>
        <tr>
            <td><?php echo $day; ?></td>
            <td><?php echo $payperiodarray['in_morning']; ?></td>
            <td><?php echo $payperiodarray['out_afternoon']; ?></td>
            <td><?php echo $hrswrk; ?></td>
            <td></td>
            <td><?php echo $otin; ?></td>
            <td><?php echo $otout; ?></td>
            <td><?php echo $payperiodarray['overtime_hours']; ?></td>
            <td><?php echo $payperiodarray['totalhours']; ?></td>
        </tr>
        <?php
    }
  }
?>

         
        </tr>
      </tbody>
    </table>
  </div>
</div>

      
    <style>

      .widget-box {
  border-radius: 10px; /* You can adjust the value to control the amount of rounding */
  border: 1px solid #ccc; /* Optional: You can add a border for further styling */
  padding: 15px; /* Optional: Add padding to the box for better appearance */
}
/* .container-fluID{
  background: linear-gradient(to bottom, #f0f0f0, #add8e6);
} */
     .card {
  --main-color: #000;
  --submain-color: #78858F;
  --bg-color: #fff;
  font-family: 'San Francisco', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Open Sans', 'Helvetica Neue', sans-serif;
  position: relative;
  width: 300px;
  height: 384px;
  display: flex;
  flex-direction: column;
  align-items: center;
  border-radius: 20px;
  background: var(--bg-color);
  margin-top: 30px;
  box-shadow: 2px 2px 10px #fff;
  background-color: #ffff;
}

.card__img {
  height: 242px;
  width: 100%;
}

.card__img svg {
  height: 100%;
  border-radius: 20px 20px 0 0;
}

.card__avatar {
  position: absolute;
  width: 114px;
  height: 114px;
  background: var(--bg-color);
  border-radius: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  top: calc(35% - 57px);
}

.card__avatar svg {
  width: 100px;
  height: 100px;
}

.card__title {
  margin-top: 60px;
  font-weight: 500;
  font-size: 18px;
  color: var(--main-color);
  
}

.card__subtitle {
  margin-top: 10px;
  font-weight: 400;
  font-size: 15px;
  color: var(--submain-color);
  
}
.card .card__subtitle1 {
  margin-top: 10px;
  font-weight: 400;
  font-size: 15px;
  color: var(--submain-color);
}
.card__subtitle2 {
  margin-top: 10px;
  font-weight: 400;
  font-size: 15px;
  color: var(--submain-color);
}
.card__subtitle3 {
  margin-top: 10px;
  font-weight: 400;
  font-size: 15px;
  color: var(--submain-color);
}

@media (max-width: 768px) {
  .card {
    margin-top: 70px; 
    margin-left: auto;
    margin-right: auto;
  }

  .card__title {
    margin-top: 20px;
  }

  .card__subtitle {
    margin-top: 5px; 
  }
}



    </style>

   
</div>


<style>
  .allcontent{
    margin-left: 50px;
    margin-right:50px;
    display: flex;
    justify-content: wrap;
    align-items: center;
    margin-top:50px;

  }
  .allcontent .card{
    height: 700px;
    margin: 20px;
  }
  .allcontent .myPieChart{
    margin: 20px;
     
  }
  /* .container {
    display: block;
    justify-content: space-between;
    align-items: flex-start;
    margin: 20px;
  } */

  .chart-container {
    flex: 1;
 
  }

  .cards-container {
    display: flex;
    flex-wrap: wrap;
    flex-direction: row;
    justify-content: flex-start;
    align-items: flex-start;
    gap: 20px; 
  }

  .sibbmpresidenteko {
    width: 200px;
    margin-right: 20px;
    margin-bottom: 0px;
    border: 1px solid #ccc;
    border-radius: 10px;
    box-shadow: 2px 2px 10px #ccc;
    padding: 10px;
    background-color: #e8e8e8;
  }

  .small-card {
    height: 150px;
    width: 1600px;
  }

  .large-card {
    width: 440px;
    height: 150px;
    margin-top: 0px;
    border: 1px solid #ccc;
    border-radius: 10px;
    box-shadow: 2px 2px 10px #ccc;
    padding: 10px;
    background-color: #ffff;
    
  }

 
  @media (max-width: 768px) {
      .container {
        flex-direction: column;
        align-items: center;
      }

      .chart-container {
        margin-right: 40px;
        margin-bottom: 20px; 
        text-align: left;
      }

      .cards-container {
        align-items: center;
        margin-right: 40px;
      }

      .sibbmpresidenteko {
        width: 100%;
        margin-right: 0;
      }
    }
</style>




      
      


</style>
    
      

      
 

 
 
    

      <!-- <div class ="span6">
        <div class="widget-box">
          <div class = "widget-title"><span class="icon"><i class ="icon-user"></i></span>
            <h5> Profile</h5>
          </div> -->
         
<!-- 
             <table class="table table-bordered data-table">
             <thead>
              <tr>
                
                <th>Last Name</th>
                <th>First Name</th>
                <th>Middle Name</th>
                <th>Pay Period</th>
                <th>Basic Pay</th>
                <th>OT Pay</th>
                <th>Reg. Holiday</th>
                <th>Special Non-Working Holiday</th>
                <th>Gross Salary</th>
                <th>Philhealth</th>
                <th>GSIS</th>
                <th>PAG-IBIG/HDMF</th>
                <th>GSIS Loan</th>
                <th>PAG-IBIG Loan</th>
                <th>Total Deductions</th>
                <th>Net Pay</th>
                                
                
              </tr>
            </thead>
            <tbody> 

             <?php

            

             function filterTable($searchquery)
             {

                  $conn1 = mysqli_connect("localhost:3307","root","","masterdb");
                  $filter_Result = mysqli_query($conn1,$searchquery) or die ("failed to query masterfile ".mysqli_error($conn1));
                  return $filter_Result;
             }
             while($row1 = mysqli_fetch_array($search_result)):;
             $basepay = $row1['reg_pay'];
             $otpay = $row1['ot_pay'];
             $shdaypay = $row1['shday_pay'];
             $hdaypay  =$row1['hday_pay'];

             $grosspay = ($basepay + $otpay + $shdaypay + $hdaypay);
             $gpay = number_format((float)$grosspay,2,'.','');
             $philhealth = $row1['philhealth_deduct'];
             $sss = $row1['sss_deduct'];
             $pagibig = $row1['pagibig_deduct'];
             $sssloan = $row1['sssloan_deduct'];
             $pagibigloan = $row1['pagibigloan_deduct'];
             $withholdingtax = $row1['tax_deduct'];
             $totaldeduct = $row1['total_deduct'];

             $netpay = ($grosspay - $totaldeduct);
             $npay = number_format((float)$netpay,2,'.',''); 

             
            
                    
             ?>
                <tr class="gradeX">
                <td><?php echo $row1['last_name'];?></td>
                <td><?php echo $row1['first_name'];?></td>
                <td><?php echo $row1['middle_name']; ?></td>
                <td><?php echo $row1['pperiod_range'];?></td>
                <td><?php echo $basepay;?></td>
                <td><?php echo $otpay;?></td>
                <td><?php echo $hdaypay;?></td>
                <td><?php echo $shdaypay;?></td>
                <td><?php echo $gpay;?></td>
                <td><?php echo $philhealth; ?></td>
                <td><?php echo $sss; ?></td>
                <td><?php echo $pagibig; ?></td>
                <td><?php echo $sssloan; ?></td>
                <td><?php echo $pagibigloan; ?></td>
                <td><?php echo $totaldeduct; ?></td>
                <td><center><b>&#8369; <?php echo $npay;?></td>

                
              </tr>
              <?php endwhile;?>
            </tbody>
          </table> -->
             
        </div><!--EMPLOYEE TAB--><!--EMPLOYEE TAB--><!--EMPLOYEE TAB--><!--EMPLOYEE TAB--><!--EMPLOYEE TAB--><!--EMPLOYEE TAB--><!--EMPLOYEE TAB--><!--EMPLOYEE TAB-->
        </div>
        <!-- end of widget -->
        
      
    </div>
  </div>
</div>
<!-- end of content -->

      

    </div>
  </div>
</div>
</div>
</div>
<div class="row-fluid">
<!-- <div id="footer" class="span12" style="position: fixed; bottom: 0; left: 0; width: 100%; text-align: center; padding: 10px;"> 2023 &copy; WEB-BASED TIMEKEEPING AND PAYROLL SYSTEM USING FINGERPRINT BIOMETRICS</div> -->
</div>
</div>
<?php
unset($_SESSION['changepassnotif']);
?>
<script src="../js/maruti.dashboard.js"></script> 
<script src="../js/excanvas.min.js"></script> 

<script src="../js/bootstrap.min.js"></script> 
<script src="../js/jquery.flot.min.js"></script> 
<script src="../js/jquery.flot.resize.min.js"></script> 
<script src="../js/jquery.peity.min.js"></script> 
<script src="../js/fullcalendar.min.js"></script> 
<script src="../js/maruti.js"></script> 
<div class="widget-title">

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<!-- Include Chart.js library -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- Chart container -->
<canvas id="myPieChart" width="200" height="200"></canvas>

<script>
    // Initial static data
    var staticData = [
        { label: 'Label 1', value: 50 },
        { label: 'Label 2', value: 30 },
        // Add more data as needed
    ];

    // Create the chart with static data
    var initialChart = createCustomPieChart(staticData, 'myPieChart', 200, 200);

    // Fetch data from PHP script
    fetch('fetch_data.php')
        .then(response => response.json())
        .then(data => updateChartWithData(initialChart, data))
        .catch(error => console.error("Error fetching data:", error));

    // Function to create a custom pie chart
    function createCustomPieChart(data, chartId, chartWidth, chartHeight) {
        var labels = data.map(item => item.label);
        var values = data.map(item => item.value);

        var ctx = document.getElementById(chartId).getContext('2d');
        var myPieChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: labels,
                datasets: [{
                    data: values,
                    backgroundColor: getRandomColors(values.length),
                }],
            },
            options: {
                responsive: false,
                maintainAspectRatio: false,
                width: chartWidth,
                height: chartHeight,
            },
        });

        return myPieChart; // Return the chart instance
    }

    // Function to update the chart with new data
    function updateChartWithData(chart, newData) {
        var labels = newData.map(item => item.label);
        var values = newData.map(item => item.value);

        // Update chart data
        chart.data.labels = labels;
        chart.data.datasets[0].data = values;

        // Update chart colors (optional)
        chart.data.datasets[0].backgroundColor = getRandomColors(values.length);

        // Update the chart
        chart.update();
    }

    // Function to generate random colors
    function getRandomColors(count) {
        var colors = [];
        for (var i = 0; i < count; i++) {
            var hue = (360 / count) * i;
            colors.push(`hsl(${hue}, 70%, 60%)`);
        }
        return colors;
    }
</script>






</body>
</html>


<!DOCTYPE html>
<html lang="en">
<head>
<title>Add Loan</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="../../css/bootstrap.min.css" />
<link rel="stylesheet" href="../../css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="../../css/fullcalendar.css" />
<link rel="stylesheet" href="../../css/maruti-style.css" />
<link rel="stylesheet" href="../../css/maruti-media.css" class="skin-color" />
 <link rel="stylesheet" href="../../jquery-ui-1.12.1/jquery-ui.css">
<script src="../../jquery-ui-1.12.1/jquery-3.2.1.js"></script>
<script src="../../jquery-ui-1.12.1/jquery-ui.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker@3.1.0/daterangepicker.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<!-- <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script> -->
<!-- <script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment.min.js"></script> -->
<!-- <script src="https://cdn.jsdelivr.net/npm/daterangepicker@3.1.0/daterangepicker.min.js"></script> -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<?php
include("../../DBCONFIG.PHP");
include("../../LoginControl.php");
include("BASICLOGININFO.PHP");

session_start();

$adminId = $_SESSION['adminId'];
$error = false;

//for act log hehehehehe
$adminname = "SELECT first_name, last_name FROM employees where emp_id = '$adminId'";
$adminnameexecqry = mysqli_query($conn, $adminname) or die ("FAILED TO CHECK EMP ID ".mysqli_error($conn));
$adminData = mysqli_fetch_assoc($adminnameexecqry);

$adminFullName = $adminData['first_name'] . " " . $adminData['last_name'];




if (isset($_POST['search_btn1'])){

 
  $selectedLoantype = $_POST["loantype"];
  


  // Separate $selectedLoantype into loantype_id and loantype
  list($selectedLoantypeorg, $selectedLoantypeName) = explode('|', $selectedLoantype);
  $_SESSION['selectedLoantype'] = $selectedLoanType;
  $_SESSION['selectedLoanorg'] = $selectedLoantypeorg;


  // echo"<script>alert('hello')</script>";
  $lastname1 = $_POST['lastname'];
  // $loanorg = $_POST['loanorg'];

  if ($selectedLoantypeorg == 'GSIS'){
    $gsisidnoquery = "SELECT * FROM employees where last_name='$lastname1'";
    $gsisidnoexecqry = mysqli_query($conn,$gsisidnoquery);
    $gsisidnocount = mysqli_num_rows($gsisidnoexecqry);
    $gsisidnoarray = mysqli_fetch_array($gsisidnoexecqry);
    if ($gsisidnoarray){
   
      $gsisempid = $gsisidnoarray['emp_id'];
      $last_name = $gsisidnoarray['last_name'];
      $firstname = $gsisidnoarray['first_name'];
      $middlename = $gsisidnoarray['middle_name'];
      $gsis = $gsisidnoarray['GSIS_idno'];
      // $empname = "$lastname, $firstname $middlename"; 
       echo"<script>alert($gsis)</script>";

    }else{
      // echo"<script>alert('heafsallo')</script>";
    }
    
  }
  else if($selectedLoantypeorg == 'PAGIBIG'){
    $gsisidnoquery = "SELECT * FROM employees where last_name='$lastname1'";
    $gsisidnoexecqry = mysqli_query($conn,$gsisidnoquery);
    $gsisidnocount = mysqli_num_rows($gsisidnoexecqry);
    $gsisidnoarray = mysqli_fetch_array($gsisidnoexecqry);

    $gsisempid = $gsisidnoarray['emp_id'];
    $last_name = $gsisidnoarray['last_name'];
    $firstname = $gsisidnoarray['first_name'];
    $middlename = $gsisidnoarray['middle_name'];
    $gsis = $gsisidnoarray['PAGIBIG_idno'];
    // $empname = "$lastname, $firstname $middlename"; 
    // echo"<script>alert('hello')</script>";

  }else{
    // echo"<script>alert('heafsallo')</script>";
  }
  
 
  //  $gsisidnoquery = "SELECT * FROM employees where last_name";
  //  echo $gsisidnoquery;
  // $gsisidnoexecqry = mysqli_query($conn,$gsisidnoquery);
  // $gsisidnocount = mysqli_num_rows($gsisidnoexecqry);
  // $gsisidnoarray = mysqli_fetch_array($gsisidnoexecqry);
  // if ($gsisidnoarray){
   
  //   $gsisempid = $gsisidnoarray['emp_id'];
  //   $lastname = $gsisidnoarray['last_name'];
  //   $firstname = $gsisidnoarray['first_name'];
  //   $middlename = $gsisidnoarray['middle_name'];
  //   // $empname = "$lastname, $firstname $middlename"; 

  // }elseif (!$gsisidnoarray){
  //   $error = true;
  //   $gsisidnumbererror = "No Employee has that SSS ID Number.";   
  // }

}

if(isset($_POST['submit_btn'])){
 
  $loantype1= $_SESSION['selectedLoantype'];
  $loanorg1= $_SESSION['selectedLoanorg'];
  $loanidno = $_POST['loanidno'];
  $gsisempid = $_POST['gsisempid'];

  // $empname = $_POST['empname'];
  $lastname = $_POST['last_name'];
  $firstname = $_POST['first_name'];
  $middlename = $_POST['middle_name'];
  $startdate = $_POST['startpicker'];
  $enddate = $_POST['endpicker'];
  $loanamount = $_POST['loanamount'];
  $monthlydeductionamount = $_POST['monthlydeductionamount'];
  $noofpays = $_POST['payduration'];


 

  $empidqry = "SELECT emp_id FROM employees where emp_id = '$gsisempid'";
  $empidexecqry = mysqli_query($conn,$empidqry) or die ("FAILED TO CHECK EMP ID ".mysqli_error($conn));
  $empidcount = mysqli_num_rows($empidexecqry);

  if($empidcount!=1){
    $error = true;
    $empiderror = "Employee ID does not exist.";
  }

if (empty($startdate)){

  $error = true;
  $startdateerror = "Please indicate loan start date.";

}

if (empty($enddate)){
  $error = true;
  $enddateerror = "Please indicate loan end date.";

}

if (empty($loanamount)){
  $error = true;
  $loanamounterror = "Please indicate the loan amount.";

}

if(empty($monthlydeductionamount)){
  $error = true;
  $monthlydeductionamounterror = "Please enter the amount to be deducted every month.";

}

if(empty($noofpays)){
  $error = true;
  $paydurationerror = "Please enter number of payment months.";
}

  if (!$error){

    $newdeptqry = "INSERT INTO loans (loanidno,loanorg,loantype, emp_id,empfirstname,emplastname, empmiddlename, start_date,end_date,loan_amount, loan_balance, monthly_deduct,no_of_pays,status, adminname) VALUES ('$loanidno','$loanorg1','$loantype1','$gsisempid','$firstname','$lastname','$middlename','$startdate','$enddate','$loanamount','$loanamount','$monthlydeductionamount','$noofpays','On-Going', '$adminFullName')";
    $newdeptqryresult = mysqli_query($conn,$newdeptqry) or die (" ".mysqli_error($conn));
    echo $newdeptqry;

    $activityLog = "Added Loan for ($firstname $lastname)";
    $adminActivityQuery = "INSERT INTO adminactivity_log (emp_id, adminname, activity,log_timestamp) VALUES ('$adminId','$adminFullName', '$activityLog', NOW())";
    $adminActivityResult = mysqli_query($conn, $adminActivityQuery);


    $notificationMessage = "Loan has been added for $firstname $lastname";
    $insertNotificationQuery = "INSERT INTO empnotifications (admin_id, adminname, emp_id, message, type, status) VALUES ('$adminId', '$adminFullName','$gsisempid','$notificationMessage','Loan','unread')";
    mysqli_query($conn, $insertNotificationQuery);

    if($newdeptqryresult){

      ?>
   
   <script>
   document.addEventListener('DOMContentLoaded', function() {
       swal({
        //  title: "Good job!",
         text: "Loan inserted successfully",
         icon: "success",
         button: "OK",
        }).then(function() {
           window.location.href = 'adminSSSLoans.php'; // Replace 'your_new_page.php' with the actual URL
       });
   });
</script>
    <?php
 
}
  } else {
    $errType = "danger";
    // $_SESSION['addprofilenotif'] = "Something went wrong. Make sure you accomplish all the required fields.";
    ?><script>
    document.addEventListener('DOMContentLoaded', function() {
        swal({
          // title: "Data ",
          text: "Something went wrong.",
          icon: "error",
          button: "Try Again",
        });
    }); </script>
    <?php
  }

} 

?>





<script type ="text/javascript">
  $( function() {
      $( "#startdatepicker" ).datepicker({ 
        changeYear: true,
        yearRange: "1940:2040",
        dateFormat: 'yy-mm-dd'});
      } );

  $( function() {
      $( "#enddatepicker" ).datepicker({ 
        changeYear: true,
        yearRange: "1940:2040",
        dateFormat: 'yy-mm-dd'});
      } );
  </script>
</head>
<body>

<!--Header-part-->





<?php
INCLUDE ('NAVBAR.php');
?>


<div id="content">

  <div id="content-header">
    <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a>
      <a href ="adminSSSLoans.php" class="tip-bottom"><i class ="icon-th"></i> GSIS Loans</a>
      <a href="#" class="tip-bottom"><i class = "icon-plus"></i>Add GSIS Loan</a>
    </div>
  </div>

  <div class="container-fluid">
    <div class = "row-fluid">
      <span class="span3">
      </span>
    <div class="span6">
      <h3>Add GSIS Loan</h3>
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
            <h5>Loan Information</h5>
          </div>

          <div class="widget-content nopadding">
            <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST" class="form-horizontal">
            <div class="control-group">
                        <?php
                $loantypesquery = "SELECT * FROM loantype";
                $loantypesexecqry = mysqli_query($conn, $loantypesquery) or die("FAILED TO EXECUTE LOAN TYPE QUERY " . mysqli_error($conn));
            ?>

                    <div class="control-group">
                <label class="control-label">Loan Type:</label>
                <div class="controls">
                    <select name="loantype" required>
                        <option value=""></option>
                        <?php
                        while ($loantype = mysqli_fetch_array($loantypesexecqry)):
                            $selected = ($loantype['loanorg'] . '|' . $loantype['loantype'] == $_POST['loantype']) ? 'selected' : '';
                        ?>
                            <option value="<?php echo $loantype['loanorg'] . '|' . $loantype['loantype']; ?>" <?php echo $selected; ?>><?php echo $loantype['loantype']; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
            </div>

            <?php
            $lasttypesquery = "SELECT * FROM employees WHERE employment_TYPE ='Permanent'";
            $lasttypesexecqry = mysqli_query($conn, $lasttypesquery) or die("FAILED TO EXECUTE LOAN TYPE QUERY " . mysqli_error($conn));
            ?>

            <div class="control-group">
                <label class="control-label">Last Name:</label>
                <div class="controls">
                    <select name="lastname" required>
                        <option></option>
                        <?php
                        while ($lastname = mysqli_fetch_array($lasttypesexecqry)):
                            $selected = ($lastname['last_name'] == $_POST['lastname']) ? 'selected' : '';
                        ?>
                            <option <?php echo $selected; ?>><?php echo $lastname['last_name']; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
            </div>

            <button type="submit" class="btn btn-success printbtn" name = "search_btn1">Search</button>
               
            </form>

            <!-- <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST" class="form-horizontal"> -->
              
               
            <!-- </form> -->

              <form action="<?php $_SERVER['PHP_SELF'];?>" method="POST" class="form-horizontal">
              <div class="control-group">
                <label class="control-label">Loan ID Number:</label>
                <div class="controls">
                <!-- <input type="text" class="span7" placeholder="SSS ID Number" name="sssidno" value="<?php echo $sssidno;?>"/> -->
                <input type="text" class="span7" placeholder="Loan ID Number" name="loanidno" value="<?php echo $gsis ?? ''; ?>"/>

                  <!-- <button type="submit" class="btn btn-success printbtn" name = "search_btn">Search</button> -->
                  <!-- <span class ="label label-important"><?php echo $sssidnumbererror; ?></span> -->

                </div>
              </div>
              <div class="control-group">
                <label class="control-label">Employee ID:</label>
                <div class="controls">
                <input type="text" class="span7" placeholder="Employee ID" name="gsisempid" value="<?php echo $gsisempid ?? ''; ?>" readonly/>
                  <!-- <span class ="label label-important"><?php echo $empiderror; ?></span> -->
                </div>
              </div>

              <div class="control-group">
                <label class="control-label">Last Name:</label>
                <div class="controls">
                <input type="text" class="span7" placeholder="Last Name" name="last_name" value = "<?php echo $last_name ?? '';?>" readonly/>
                  <!-- <span class ="label label-important"><?php echo $nameerror; ?></span> -->
                </div>
              </div>
              <div class="control-group">
                <label class="control-label">First Name:</label>
                <div class="controls">
                <input type="text" class="span7" placeholder="First Name" name="first_name" value = "<?php echo $firstname ?? '';?>" readonly/>
                  <!-- <span class ="label label-important"><?php echo $nameerror; ?></span> -->
                </div>
              </div>
              <div class="control-group">
                <label class="control-label">Middle Name:</label>
                <div class="controls">
                <input type="text" class="span7" placeholder="Middle Name" name="middle_name" value = "<?php echo $middlename ?? '';?>" readonly/>
                  <!-- <span class ="label label-important"><?php echo $nameerror; ?></span> -->
                </div>
              </div>

              <div class="control-group">
                <label class="control-label">Start Date:</label>
                <div class="controls"> 
                <input type="text" class="span3" id="startdatepicker" name ="startpicker" placeholder="Start Date" value=""required >
                  <!-- <span class ="label label-important"><?php echo $startdateerror; ?></span> -->
                </div>
              </div>

              <div class="control-group">
                <label class="control-label">End Date:</label>
                <div class="controls">
                  <input type="text" class="span3" id="enddatepicker" name ="endpicker" placeholder="End Date" value="" required>
                  <!-- <span class ="label label-important"><?php echo $enddateerror; ?></span> -->
                </div>
              </div>


              <div class="control-group">
                <label class="control-label">Monthly Deduction Amount:</label>
                <div class="controls">
                  <input type="text" class="span4" placeholder="Monthly Deduction Amount" name="monthlydeductionamount" required/>
                  <!-- <span class ="label label-important"><?php echo $monthlydeductionamounterror; ?></span> -->
                </div>
              </div>
              <div class="control-group">
                <label class="control-label">Loan Amount:</label>
                <div class="controls">
                  <input type="text" class="span4" placeholder="Loan Amount" name="loanamount" readonly required/>
                  <!-- <span class ="label label-important"><?php echo $loanamounterror; ?></span> -->
                </div>
              </div>

              <div class="control-group">
                <label class="control-label">Pay Duration:</label>
                <div class="controls">
                  <input type="text" class="span1" placeholder="" name="payduration" readonly required/>
                  <span> months</span>
                  <!-- <span class ="label label-important"><?php echo $paydurationerror; ?></span> -->
                </div>
              </div>



              <div class="form-actions">
                <button type="submit" class="btn btn-success" name = "submit_btn" style="float:right;">Submit</button>
              </div>
            </form>
        </div>
    </div>
    
    <div class="row-fluid">
      


    </div>
    <hr>
    <div class="row-fluid">
      
      

    </div>
  </div>
</div>
</div>
</div>
<div class="row-fluid">
  <div id="footer" class="span12"> 2023 &copy; WEB-BASED TIMEKEEPING AND PAYROLL SYSTEM USING FINGERPRINT BIOMETRICS</div>
</div>
<?php
unset($_SESSION['anewdept']);
?>

<script src="../js/maruti.dashboard.js"></script> 
<script>
  $(document).ready(function() {
    // Assuming date format is yyyy mm dd
    $("#enddatepicker, #startdatepicker").on("change", function() {
      var startDate = $("#startdatepicker").val();
      var endDate = $("#enddatepicker").val();

      if (startDate && endDate) {
        var start = new Date(startDate);
        var end = new Date(endDate);

        var monthDiff = (end.getFullYear() - start.getFullYear()) * 12 + end.getMonth() - start.getMonth();

        $("input[name='payduration']").val(monthDiff);
      }
    });
  });
</script>
<script>
  $(document).ready(function() {
    // Assuming date format is yyyy mm dd
    $("#enddatepicker, #startdatepicker, input[name='monthlydeductionamount'], input[name='payduration']").on("change", function() {
      var startDate = $("#startdatepicker").val();
      var endDate = $("#enddatepicker").val();
      var monthlyDeduction = parseFloat($("input[name='monthlydeductionamount']").val());
      var payDuration = parseInt($("input[name='payduration']").val());

      if (startDate && endDate && !isNaN(monthlyDeduction) && !isNaN(payDuration)) {
        var start = new Date(startDate);
        var end = new Date(endDate);

        var monthDiff = (end.getFullYear() - start.getFullYear()) * 12 + end.getMonth() - start.getMonth();

        var loanAmount = monthlyDeduction * monthDiff;

        $("input[name='loanamount']").val(loanAmount.toFixed(2));
      }
    });
  });
</script>



</body>
</html>

<?php
include("../../DBCONFIG.PHP");
include("../../LoginControl.php");
include("BASICLOGININFO.PHP");
require_once("./../fpdf181/fpdf.php");

// Function to fetch and display data as PDF
function printDataAsPDF($result) {
    $pdf = new FPDF('L', 'mm', 'A4');
    $pdf->AddPage();

    $pdf->SetFont('Arial','B',12);

//Spacer
$pdf->Cell(189,10,'',0,1);//end of line

//Cell (width,height,text,border,end line, [align])
$pdf->Cell(255,5,'WEB-BASED TIMEKEEPING AND PAYROLL SYSTEM USING FINGERPRINT BIOMETRICS',0,1,'C');//end
$pdf->Cell(189,5,'',0,1);//end of line
// Header
    $pdf->SetFont('Arial', 'B', 8);
    $pdf->Cell(25, 10, 'PAG-IBIG ID No.', 1);
    $pdf->Cell(23, 10, 'Employee ID', 1);
    $pdf->Cell(23, 10, 'Last Name', 1);
    $pdf->Cell(23, 10, 'First Name', 1);
    $pdf->Cell(23, 10, 'Middle Name', 1);
    $pdf->Cell(23, 10, 'Department', 1);
    $pdf->Cell(23, 10, 'Emp Type', 1);
    $pdf->Cell(23, 10, 'Shift', 1);
    $pdf->Cell(23, 10, 'Start Date', 1);
    $pdf->Cell(23, 10, 'End Date', 1);
    $pdf->Cell(23, 10, 'Loan Amount', 1);
    $pdf->Cell(24, 10, 'Monthly Amount', 1);
    // Add more columns as needed

    // Data
    $pdf->SetFont('Arial', '', 10);

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $pdf->Ln();
            $pdf->Cell(25, 10, $row['pagibig_idno'], 1);
            $pdf->Cell(23, 10, $row['emp_id'], 1);
            $pdf->Cell(23, 10, $row['last_name'], 1);
            $pdf->Cell(23, 10, $row['first_name'], 1);
            $pdf->Cell(23, 10, $row['middle_name'], 1);
            $pdf->Cell(23, 10, $row['employment_TYPE'], 1);
            $pdf->Cell(23, 10, $row['dept_NAME'], 1);
            $pdf->Cell(23, 10, $row['shift_SCHEDULE'], 1);
            $pdf->Cell(23, 10, $row['loanstart_date'], 1);
            $pdf->Cell(23, 10, $row['loanend_date'], 1);
            $pdf->Cell(23, 10, $row['loan_amount'], 1);
            $pdf->Cell(24, 10, $row['monthly_deduct'], 1);

            // Add more cells for additional columns
        }
    } else {
        $pdf->Cell(100, 10, 'No data found', 1, 1);
    }

    // Output the PDF
    ob_start();  // Start output buffering
    $pdf->Output();
    ob_end_flush();  // Flush output buffer
}

// Check if the print button is clicked
if (isset($_GET['printAll'])) {
    // Print data as PDF query
    $query = "SELECT * FROM loanpagibig, employees  WHERE employees.emp_id = loanpagibig.emp_id";
    $result = mysqli_query($conn, $query);

    if ($result === false) {
        die("Failed to fetch data: " . mysqli_error($conn));
    }

    printDataAsPDF($result);
} elseif (isset($_GET['printDisplayed'])) {
    // Print displayed masterlist query
    session_start();

    // Debugging: Check if the session variable is set
    var_dump($_SESSION['printpagibig_query']);

    $queryResult = isset($_SESSION['printpagibig_query']) ? mysqli_query($conn, $_SESSION['printpagibig_query']) : '';

    if ($queryResult === false) {
        die("Failed to fetch data: " . mysqli_error($conn));
    }

    printDataAsPDF($queryResult);
}

mysqli_close($conn);
?>

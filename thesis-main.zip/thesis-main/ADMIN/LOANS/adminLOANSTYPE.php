<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php

include("../../DBCONFIG.PHP");
include("../../LoginControl.php");
include("BASICLOGININFO.PHP");

session_start();


if (isset($_GET['refresh'])) {
  header("Location: adminLOANSTYPE.php");
  exit(); 
}

if (isset($_POST['addloantype'])) {
  $loantype = $_POST['loantype'];
  $loanorg = $_POST['loanorg'];

  // Perform the database insertion
  $insertQuery = "INSERT INTO loantype (loantype, loanorg) VALUES ('$loantype', '$loanorg')";
  $insertResult = mysqli_query($conn, $insertQuery);

  if ($insertResult) {
      ?>
 
      <script>
      document.addEventListener('DOMContentLoaded', function() {
          swal({
           //  title: "Good job!",
            text: "Position inserted successfully",
            icon: "success",
            button: "OK",
           }).then(function() {
              window.location.href = 'adminloanstype.php'; // Replace 'your_new_page.php' with the actual URL
          });
      });
   </script>
       <?php
  } else {
      ?><script>
      document.addEventListener('DOMContentLoaded', function() {
          swal({
            // title: "Data ",
            text: "Something went wrong.",
            icon: "error",
            button: "Try Again",
          });
      }); </script>
      <?php
  }

  // Prevent further execution to avoid duplicate alerts
  exit();
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
  <title>Pagibig Loans</title>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="../../css/bootstrap.min.css" />
  <link rel="stylesheet" href="../../css/bootstrap-responsive.min.css" />
  <link rel="stylesheet" href="../../css/fullcalendar.css" />
  <link rel="stylesheet" href="../../css/maruti-style.css" />
  <link rel="stylesheet" href="../../css/maruti-media.css" class="skin-color" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker@3.1.0/daterangepicker.css" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/daterangepicker@3.1.0/daterangepicker.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</head>

<body>
<style>
  </style>
  <!--Header-part-->

  <?php
  include('NAVBAR.php');
  ?>


  <div id="content">

    <div id="content-header">
      <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i>
          Home</a></div>
    </div>
    <span class="span6">
      <h3 style="margin-top: 30px">Loans Type</h3>
    </span>

    <div class="container-fluid">
      <div class="row-fluid">
        <div class="row-fluid">

          <div class="span12">
            <div class="widget-box">
              <div class="widget-title">
                <ul class="nav nav-tabs" id="myTab">
                  <li class=""><a href="../adminPAYROLLINFO.php"><i class="icon-user"></i> Employees</a></li>
                  <!-- <li class=""><a href="../GOVTTABLES/adminGOVTTables.php"><i class="icon-th"></i> Government
                      Contribution Table</a></li> -->
                  <li class=""><a href="../LOANS/adminSSSLoans.php"><i class="icon-th"></i> Add Loans</a></li>
                  <li class="active"><a href="../LOANS/adminPAGIBIGLoans.php"><i class="icon-th"></i> Loans Type</a>
                  </li>
                  <li class=""><a href="../adminPAYROLLProcess.php"><i class="icon-user"></i> Process Employee
                      Payrolls</a></li>
                  <li class=""><a href="../admin13thmonth.php"><i class="icon-th"></i> Compute 13th Month Pay</a></li>
                </ul>
              </div>

              <div class="row-fluid">

                <span class="span3">

                </span>
                <span class="span3">
                </span>

              </div>

              <div class="row-fluid">

                <div class="widget-box">
                  <div class="widget-title"><span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>PAG-IBIG LOANS</h5>
                  </div>
                  <div class="widget-content nopadding">
                      

                      <div class="selections">
                        <style>
                          /* Add CSS styles here */

                          .selections {
                            display: flex;
                            flex-direction: center;
                            justify-content: center;
                          }

                          .select-container {
                            display: flex;
                            flex-direction: column;
                            margin-bottom: 100px;
                            /* Add margin between each set */
                          }

                          .select-container h6,
                          .select-container select {
                            margin-left: 20px;
                            /* Adjust the margin as needed */
                          }

                          .select-container2 {
                            display: flex;
                            flex-direction: column;
                            margin-bottom: 20px;
                            /* Add margin between each set */
                          }

                          .select-container2 h6,
                          .select-container2 select {
                            margin-left: 20px;
                            /* Adjust the margin as needed */
                          }

                          .select-container3 {
                            display: flex;
                            flex-direction: column;
                            margin-bottom: 20px;
                            /* Add margin between each set */
                          }

                          .select-container3 h6,
                          .select-container3 select {
                            margin-left: 20px;
                            /* Adjust the margin as needed */
                          }

                          .select-container4 {
                            display: flex;
                            flex-direction: column;
                            margin-bottom: 20px;
                            /* Add margin between each set */
                          }

                          .select-container4 h6,
                          .select-container4 select {
                            margin-left: 20px;
                            /* Adjust the margin as needed */
                          }

                          input {
                            margin-left: 20px;
                            border: 2px solid red;

                          }

                          @media screen and (max-width: 768px) {
                            .selections {
                              flex-direction: column;
                              /* Change to column on smaller screens */
                              align-items: stretch;
                              /* Stretch items to full width */
                            }

                            .select-container,
                            .select-container2,
                            .select-container3,
                            .select-container4 {
                              flex-direction: column;
                              /* Change to column on smaller screens */
                              margin-bottom: 2px;
                              /* Add a 5px margin between each set */
                            }
                          }
                        </style>

                           
                        
                          <form action="" method="post">

                                  <label for="loan_type">Loan Type:</label>
                                  <input type="text"  name="loantype" placeholder="Enter loan type" required>
                                  <input type="text"  name="loanorg" placeholder="Enter loan org" required>

                                  <button type="submit" class="btn btn-primary" name="addloantype">Add Loan Type</button>
                              </form>

                        
                     
                          <div class="form-actions">
                          <button type="submit" class="btn btn-success printbtn" name="print_btn">Apply</button>
                          <button type="submit" class="btn btn-success printbtn" name="refresh">Refresh</button>
                          <!-- <a href="generate_pdf.php" class="btn btn-primary">Print all</a> -->
                          
                          

                          <div class="row-fluid" style="margin-top:5px">
                           
                          </div>
                    
                            <style>
                              .printbtn1 a {
                                color: white;
                                text-decoration: none;
                              }

                              .printbtn a {
                                color: white;
                                text-decoration: none;
                              }


                              .printbtn {
                                background-color: green;
                                border-color: green;
                              }


                              .printbtn:hover {
                                background-color: darkgreen;
                                border-color: darkgreen;
                              }

                              @media screen and (max-width: 600px) {
                                .form-actions {
                                  display: flex;
                                  flex-direction: column;
                                  /* Stack buttons vertically on smaller screens */
                                  justify-content: space-between;
                                  /* Add space between buttons */
                                }

                                .form-actions button {
                                  margin-bottom: 10px;
                                  /* Add margin between buttons */
                                  width: 100%;
                                  /* Make buttons full-width on smaller screens */
                                }
                              }
                            </style>


                            <!-- <small>*shown here are the attendance record for today</small> -->
                          </div>




                  </div>
                </div>
              </div>
            </div>

            <table class="table table-bordered data-table">
              <thead>
                <tr>
                  <th>Loan Type ID</th>
                  <th>Loan Type</th>
                  <th>Loan Organization</th>
                 
                  <!-- <th>Action</th> -->
                </tr>
              </thead>
              <tbody>

                <div class="widget-content tab-content">
                  <div id="tab1" class="tab-pane fade in active">
                    <!--EMPLOYEE TAB--><!--EMPLOYEE TAB--><!--EMPLOYEE TAB--><!--EMPLOYEE TAB--><!--EMPLOYEE TAB--><!--EMPLOYEE TAB--><!--EMPLOYEE TAB--><!--EMPLOYEE TAB-->



                    <div id="search">



                    </div>

                  </div>
                  <div class="row-fluid">

                  </div>

                  <?php
                $searchquery ="SELECT * FROM loantype";                
                $searchresult= filterTable($searchquery);



                  function filterTable($searchquery)
                  {

                    $conn = mysqli_connect("localhost:3307", "root", "", "masterdb");
                    $filter_Result = mysqli_query($conn, $searchquery) or die("failed to query masterfile " . mysql_error());
                    return $filter_Result;
                  }
                  while ($row1DEPT = mysqli_fetch_array($searchresult)):
                    ;
                    ?>
                    <tr class="gradeX">
                      <td>
                        <?php echo $row1DEPT['loantypeid']; ?>
                      </td>
                      <td>
                        <?php echo $row1DEPT['loantype']; ?>
                      </td>
                      <td>
                        <?php echo $row1DEPT['loanorg']; ?>
                      </td>
                     

                      <!-- <td><center><a href = "adminEDITPAGIBIGLoans.php?id=<?php echo $row1DEPT['emp_id'] ?>" class = "btn btn-info btn-mini"><span class="icon"><i class="icon-eye-open"></i></span> View</a>
                    <a href = "adminDELETEMasterfileDept.php?id=<?php echo $row1DEPT['emp_id']; ?>" class = "btn btn-danger btn-mini"><span class="icon"><i class="icon-trash"></i></span> Delete</a></center></td> -->
                    </tr>
                  <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
  </div>

  <?php
  unset($_SESSION['masterfilenotif']);
  ?>



  <div class="row-fluid">
    <div id="footer" class="span12"> 2023 &copy; WEB-BASED TIMEKEEPING AND PAYROLL SYSTEM USING FINGERPRINT BIOMETRICS
    </div>
  </div>

  <script src="../js/maruti.dashboard.js"></script>
  <script src="../js/excanvas.min.js"></script>
  <script src="../js/jquery.min.js"></script>
  <script src="../js/jquery.ui.custom.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/jquery.flot.min.js"></script>
  <script src="../js/jquery.flot.resize.min.js"></script>
  <script src="../js/jquery.peity.min.js"></script>
  <script src="../js/fullcalendar.min.js"></script>
  <script src="../js/maruti.js"></script>
</body>

</html>
<?php
set_time_limit(60);
include("../../DBCONFIG.PHP");
include("../../LoginControl.php");
include("BASICLOGININFO.PHP");

session_start();

$adminId = $_SESSION['adminId'];
$payperiod = $_SESSION['pregisterpayperiod'];
$printfrom = $_SESSION['payperiodfrom'];
$printto=$_SESSION['payperiodto'];

$adminname = "SELECT first_name, last_name FROM employees where emp_id = '$adminId'";
$adminnameexecqry = mysqli_query($conn, $adminname) or die ("FAILED TO CHECK EMP ID ".mysqli_error($conn));
$adminData = mysqli_fetch_assoc($adminnameexecqry);

$adminFullName = $adminData['first_name'] . " " . $adminData['last_name'];

require_once("../fpdf181/fpdf.php");

$pdf = new FPDF ('L','mm','LEGAL');
$pdf ->AddPage();
//set font arial, bold, 14pt
$pdf->SetFont('Arial','B',12);
//WRitable horizontal : 260

$pdf->Cell(336,3,'',0,1);//end of line


$pdf->Cell(336,4,'WEB-BASED TIMEKEEPING AND PAYROLL SYSTEM USING FINGERPRINT BIOMETRICS',0,1,'C');//end of line
$pdf->SetFont('Arial','','8');
$pdf->Cell(336,4,'',0,1,'C');//end of line
$pdf->Cell(336,4,'',0,1,'C');//end of line

$pdf->Cell(336,8,'',0,1);//end of line

$pdf->SetFont('Arial','B','10');
$pdf->Cell(336,4,'Payroll Register',0,1,'C');//end of line

$pdf->SetFont('Arial','','10');
$pdf->Cell(336,4,$payperiod,0,1,'C');//end of line

$pdf->Cell(336,4,'',0,1);//end of line

$pdf->SetFont('Arial','B','9');
$pdf->Cell(70,4,'EMPLOYEE',0,0,'C');
$pdf->Cell(84,4,'EARNINGS',0,0,'C');
$pdf->Cell(84,4,'DEDUCTIONS',0,0,'C');
$pdf->Cell(98,4,'TOTALS',0,1,'C');//end of line

$pdf->Cell(336,0.2,'',1,1);//end of line

$pdf->SetFont('Arial','','8');
//EMPLOYEE
$pdf->Cell(84,3,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'Description',0,0);
$pdf->Cell(22,5,'Hr/Min',0,0);
$pdf->Cell(20,5,'Amount',0,0);
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'Description',0,0);
$pdf->Cell(22,5,'Hr/Min',0,0);
$pdf->Cell(20,5,'Amount',0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(84,5,'',0,1);//end

//EMPLOYEE
$pdf->Cell(84,0.1,'',0,0);
//EARNINGS
$pdf->Cell(80,0.1,'',1,0);
$pdf->Cell(4,0.1,'',0,0);
//DEDUCTIONS
$pdf->Cell(80,0.1,'',1,0);
$pdf->Cell(4,0.1,'',0,0);
//TOTALS
$pdf->Cell(84,0.1,'',0,1);//end

$getppqry = "SELECT * FROM PAY_PER_PERIOD WHERE pperiod_range = '$payperiod'";
$getppexecqry = mysqli_query($conn,$getppqry) or die ("FAILED TO GET PAYROLL PERIOD DETAILS ".mysqli_error($conn));
$GTbp = 0;
$GTbpay = 0;
$GTph = 0;
$GTE = 0;
$GTotpay = 0;
$GTsss = 0;
$GTotrhpay = 0;
$GTotshpay = 0;
$GTpagibig = 0;
$GTpagibigloan = 0;
$GTabsences = 0;
$GTN = 0;
$GTlvpay = 0;
$GTshpay = 0;
$GTrhpay = 0;
$GTD = 0;
$GTotp = 0;
$GTrhp = 0;
$GTrhp200 = 0;
$GTotrhp = 0;
$GTotshp = 0;
$GTotrdp = 0;
$GTrdrhp = 0;
$GTrdrhp = 0;
$GTotrdrhp = 0;
$GTrdshp = 0;
$GTotrdshp  = 0;
$GTlvp = 0;
$GTshp = 0;
$GTrdp  = 0;
$GTEarnings = 0;
$GTphealth = 0;
$GTsssded = 0;
$GTpagibigded = 0;
$GTsssloanded = 0;
$GTpagibigloanded = 0;
$GTut =0;
$GTDeductions = 0;
$GTnp = 0;
$GTwtaxded = 0;
$GTIntegratedAmount = 0;
$GTwtax =0;
$GTIntegratedAmount = 0;
$salaryLoanAmount = 0;
$policyLoanAmount = 0;
$elaLoanAmount = 0;
$optionalInsuranceAmount = 0;
$optionalAmount = 0;
$gfalAmount = 0;
$hipAmount = 0;
$landbankAmount = 0;
$cplAmount = 0;
$sosAmount = 0;
$educAmount = 0;
$eCardAmount = 0;
$contributionAmount = 0;
$mplAmount = 0;
$realStateAmount = 0;
$emergencyAmount = 0;
$MP2Amount = 0;
$IntegratedAmount = 0;
$GTia = 0;
// Initialize variables
$GTIntegratedAmount = 0;
$salaryLoanAmount = 0;
$policyLoanAmount = 0;
$elaLoanAmount = 0;
$optionalInsuranceAmount = 0;
$optionalAmount = 0;
$gfalAmount = 0;
$hipAmount = 0;
$landbankAmount = 0;
$cplAmount = 0;
$sosAmount = 0;
$educAmount = 0;
$eCardAmount = 0;
$contributionAmount = 0;
$mplAmount = 0;
$realStateAmount = 0;
$emergencyAmount = 0;
$MP2Amount = 0;
$IntegratedAmount = 0;
$GTia = 0;
$salaryLoanAmountFormatted = 0;
$policyLoanAmountFormatted = 0;
$elaLoanAmountFormatted = 0;
$optionalInsuranceAmountFormatted = 0;
$optionalAmountFormatted = 0;
$gfalAmountFormatted = 0;
$hipAmountFormatted = 0;
$cplAmountFormatted = 0;
$sosAmountFormatted = 0;
$educAmountFormatted = 0;
$eCardAmountFormatted = 0;
$contributionAmountFormatted = 0;
$mplAmountFormatted = 0;
$realStateAmountFormatted = 0;
$emergencyAmountFormatted = 0;
$MP2AmountFormatted = 0;


while($pparray = mysqli_fetch_array($getppexecqry)):;

$empid = $pparray['emp_id'];

$timekeepinfo = "SELECT  SUM(undertime_hours) as totalUT ,SUM(overtime_hours) as totalOT, SUM(hours_work) as totalWORKhours  FROM TIME_KEEPING WHERE emp_id = '$empid' AND timekeep_day BETWEEN '$printfrom' and '$printto' ORDER BY timekeep_day ASC";
$timekeepinfoexecqry = mysqli_query($conn,$timekeepinfo) or die ("FAILED TO GET TIMEKEEP INFO ".mysqli_error($conn));
$timekeepinfoarray = mysqli_fetch_array($timekeepinfoexecqry);
if ($timekeepinfoarray){

	$hw = $timekeepinfoarray['totalWORKhours'];
	$othrs = $timekeepinfoarray['totalOT'];
	$ut = $timekeepinfoarray['totalUT'];
	


}

$sql = "SELECT loans.*, loantype.*
        FROM loans
        JOIN loantype ON loans.loantype = loantype.loantype
        WHERE loans.emp_id = $empid
        AND loans.start_date <= '$printto'
        AND loans.end_date >= '$printfrom'";

$result = $conn->query($sql);

if (!$result) {
    die("SQL Error: " . $conn->error);
}

// Fetch data and assign it to a variable
$loanData = [];
while ($row = $result->fetch_assoc()) {
    $loanData[] = $row;
}
// $conn->close();

// Now $loanData contains the fetched data for the specified employee ID within the date range

$salaryLoanAmount = 0;
$policyLoanAmount = 0;
$elaLoanAmount = 0;
$optionalInsuranceAmount = 0;
$optionalAmount = 0;
$gfalAmount = 0;
$hipAmount = 0;
$landbankAmount = 0;
$cplAmount = 0;
$sosAmount = 0;
$educAmount = 0;
$eCardAmount = 0;
$contributionAmount = 0;
$mplAmount = 0;
$realStateAmount = 0;
$emergencyAmount = 0;
$MP2Amount = 0;
$IntegratedAmount = 0;



$totalloans = $salaryLoanAmount +
               $policyLoanAmount +
               $elaLoanAmount +
               $optionalInsuranceAmount +
               $optionalAmount +
               $gfalAmount +
               $hipAmount +
               $landbankAmount +
               $cplAmount +
               $sosAmount +
               $educAmount +
               $eCardAmount +
               $contributionAmount +
               $mplAmount +
               $realStateAmount +
               $emergencyAmount +
               $MP2Amount +
               $IntegratedAmount;

// Iterate through each loan record and assign loan amounts based on loan type
foreach ($loanData as $loanRecord) {
    // Access individual fields in each loan record
    $loanAmount = $loanRecord['monthly_deduct'];
    $loanType = $loanRecord['loantype'];

    // Assign loan amount based on loan type using multiple if statements
    if ($loanType == 'Salary Loan') {
        $salaryLoanAmount += $loanAmount;
    } elseif ($loanType == 'Policy Loan') {
        $policyLoanAmount += $loanAmount;
    } elseif ($loanType == 'ELA') {
        $elaLoanAmount += $loanAmount;
    } elseif ($loanType == 'Optional Insurance') {
        $optionalInsuranceAmount += $loanAmount;
    } elseif ($loanType == 'GFAL') {
        $gfalAmount += $loanAmount;
    } elseif ($loanType == 'HIP') {
        $hipAmount += $loanAmount;
    } elseif ($loanType == 'Landbank') {
        $landbankAmount += $loanAmount;
    } elseif ($loanType == 'CPL') {
        $cplAmount += $loanAmount;
    } elseif ($loanType == 'SOS') {
        $sosAmount += $loanAmount;
    } elseif ($loanType == 'Educ') {
        $educAmount += $loanAmount;
    } elseif ($loanType == 'E Card') {
        $eCardAmount += $loanAmount;
    } elseif ($loanType == 'Contribution') {
        $contributionAmount += $loanAmount;
    } elseif ($loanType == 'MPL') {
        $mplAmount += $loanAmount;
    } elseif ($loanType == 'Real State') {
        $realStateAmount += $loanAmount;
    } elseif ($loanType == 'Emergency') {
        $emergencyAmount += $loanAmount;
    }
     elseif ($loanType == 'MP2') {
        $MP2Amount += $loanAmount;
    }
     elseif ($loanType == 'Integrated Insurance') {
        $IntegratedAmount += $loanAmount;
    }
     elseif ($loanType == 'Optional Loan') {
        $OptionalLoanAmount += $loanAmount;
    }
    // ... add more if statements for other loan types
}
$getempdetailsqry = "SELECT prefix_ID,last_name,first_name,middle_name,dept_name FROM employees WHERE emp_id = '$empid'";
$getempdetailsexecqry = mysqli_query($conn,$getempdetailsqry) or die ("FAILED TO GET EMP DETAILS ".mysqli_error($conn));
$emparray = mysqli_fetch_array($getempdetailsexecqry);
if($emparray){
	$prefixid = $emparray['prefix_ID'];
	$lname = $emparray['last_name'];
	$fname = $emparray['first_name'];
	$dname = $emparray['dept_name'];
	$name = "$lname, $fname";
	$compempid = "$prefixid$empid";
}

$gettkqry = 

//EARNINGS
$bpay = $pparray['reg_pay'];
$npay = $pparray['net_pay'];
$rph = $pparray['rate_per_hour'];
$totaldeduct = $pparray['total_deduct'];
$lvpay = $pparray['lv_pay'];
$absences = $pparray['absences'];
$wtax = $pparray['tax_deduct'];
$undertimededuct = $pparray['undertimehours'];
$otpay = $othrs * $rph;

$bpay1 = $bpay + ($otpay);

$te = ($bpay1);
$totearnings = number_format((float)$te,2,'.','');
//GT earnings
$GTbp = $GTbp + $bpay;
$GTbpay = number_format((float)$GTbp,2,'.','');

$GTotp = $GTotp + $otpay;
$GTotpay = number_format((float)$GTotp,2,'.','');

$GTrhp = $GTrhp;
$GTrhpay = number_format((float)$GTrhp,2,'.','');


$GTotrhp = $GTotrhp;
$GTotrhpay = number_format((float)$GTotrhp,2,'.','');

$GTshp = $GTshp;
$GTshpay = number_format((float)$GTshp,2,'.','');

$GTotshp = $GTotshp ;
$GTotshpay = number_format((float)$GTotshp,2,'.','');


$GTlvp = $GTlvp;
$GTlvpay = number_format((float)$GTlvp,2,'.','');

$GTEarnings = $GTEarnings + $te;
$GTE = number_format((float)$GTEarnings,2,'.','');

$GTIntegratedAmount = $GTIntegratedAmount + $IntegratedAmount;
$GTia = number_format((float)$GTIntegratedAmount,2,'.','');
$salaryLoanAmount += $salaryLoanAmount;
$salaryLoanAmountFormatted = number_format((float) $salaryLoanAmount, 2, '.', '');

$policyLoanAmount += $policyLoanAmount;
$policyLoanAmountFormatted = number_format((float) $policyLoanAmount, 2, '.', '');

$elaLoanAmount += $elaLoanAmount;
$elaLoanAmountFormatted = number_format((float) $elaLoanAmount, 2, '.', '');

$optionalInsuranceAmount += $optionalInsuranceAmount;
$optionalInsuranceAmountFormatted = number_format((float) $optionalInsuranceAmount, 2, '.', '');

$optionalAmount += $optionalAmount;
$optionalAmountFormatted = number_format((float) $optionalAmount, 2, '.', '');

$gfalAmount += $gfalAmount;
$gfalAmountFormatted = number_format((float) $gfalAmount, 2, '.', '');

$hipAmount += $hipAmount;
$hipAmountFormatted = number_format((float) $hipAmount, 2, '.', '');

$landbankAmount += $landbankAmount;
$landbankAmountFormatted = number_format((float) $landbankAmount, 2, '.', '');

$cplAmount += $cplAmount;
$cplAmountFormatted = number_format((float) $cplAmount, 2, '.', '');

$sosAmount += $sosAmount;
$sosAmountFormatted = number_format((float) $sosAmount, 2, '.', '');

$educAmount += $educAmount;
$educAmountFormatted = number_format((float) $educAmount, 2, '.', '');

$eCardAmount += $eCardAmount;
$eCardAmountFormatted = number_format((float) $eCardAmount, 2, '.', '');

$contributionAmount += $contributionAmount;
$contributionAmountFormatted = number_format((float) $contributionAmount, 2, '.', '');

$mplAmount += $mplAmount;
$mplAmountFormatted = number_format((float) $mplAmount, 2, '.', '');

$realStateAmount += $realStateAmount;
$realStateAmountFormatted = number_format((float) $realStateAmount, 2, '.', '');

$emergencyAmount += $emergencyAmount;
$emergencyAmountFormatted = number_format((float) $emergencyAmount, 2, '.', '');

$MP2Amount += $MP2Amount;
$MP2AmountFormatted = number_format((float) $MP2Amount, 2, '.', '');
//DEDUCTS

$phdeduct = $pparray['philhealth_deduct'];
$gsisdeduct = $pparray['sss_deduct'];
$pagibigdeduct = $pparray['pagibig_deduct'];
$sssloandeduct = $pparray['loan_deduct'];
// $pagibigloandeduct = $pparray['pagibigloan_deduct'];

$td = ($phdeduct + $gsisdeduct + $pagibigdeduct + $wtax + $sssloandeduct + $totalloans + $undertimededuct + $absences);
$totdeduct = number_format((float)$td,2,'.','');
//GTDeductions
$GTphealth = $GTphealth + $phdeduct;
$GTph = number_format((float)$GTphealth,2,'.','');

$GTsssded = $GTsssded + $gsisdeduct;
$GTsss = number_format((float)$GTsssded,2,'.','');

$GTpagibigded = $GTpagibigded + $pagibigdeduct;
$GTpagibig = number_format((float)$GTpagibigded,2,'.','');

$GTwtaxded = $GTwtaxded + $wtax;
$GTwtax = number_format((float)$GTwtaxded,2,'.','');


$GTsssloanded = $GTsssloanded + $sssloandeduct;
$GTsssloan = number_format((float)$GTsssloanded,2,'.','');

$GTpagibigloanded = $GTpagibigloanded;
$GTpagibigloan = number_format((float)$GTpagibigloanded,2,'.','');

$GTut = $GTut + $undertimededuct;
$GTut = number_format((float)$GTut,2,'.','');

$GTabsences = $GTabsences + $absences;
$GTabsences = number_format((float)$GTabsences,2,'.','');

$GTDeductions = $GTDeductions + $td;
$GTD = number_format((float)$GTDeductions,2,'.','');

//NETPAY 
$np = ($te - $td);
$netpay = number_format((float)$np,2,'.','');
$GTnp = $GTnp + $np;
$GTN = number_format((float)$GTnp,2,'.','');
//EMPLOYEE
$pdf->Cell(22,5,'Employee ID:',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(62,5,$compempid,0,0);
//EARNINGS
$pdf->Cell(1,6.1,'',0,0);   
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,6.1,'Basic',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,6.1,$hw,0,0);
$pdf->Cell(20,6.1,$bpay,0,0,'R');
$pdf->Cell(2,6.1,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,6.1,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,6.1,'Philhealth',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,6.1,'',0,0);
$pdf->Cell(20,6.1,$phdeduct,0,0,'R');
$pdf->Cell(2,6.1,'',0,0);
//TOTALS
$pdf->Cell(1,6.1,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,6.1,'Total Earnings',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,6.1,'',0,0);
$pdf->Cell(20,6.1,$totearnings,0,0,'R');
$pdf->Cell(2,6.1,'',0,1);//end

//EMPLOYEE
$pdf->Cell(22,5,'Name:',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(62,5,$name,0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'Regular OT',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,$othrs,0,0);
$pdf->Cell(20,5,$GTotpay,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'GSIS',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$gsisdeduct,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'Total Deductions',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$totdeduct,0,0,'R');
$pdf->Cell(2,5,'',0,1);//end

//EMPLOYEE
$pdf->Cell(22,5,'Dept name:',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(62,5,$dname,0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'PAG-IBIG',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$pagibigdeduct,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(104,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'Withholding Tax',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$wtax,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end

//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'GSIS - Integrated Insurance',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$IntegratedAmount,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'GSIS - MPL',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$mplAmount,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end

//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'GSIS - Salary Loan',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$salaryLoanAmount,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'NET PAY',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$netpay,0,0,'R');
$pdf->Cell(2,5,'',0,1);//end

//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(55.5,5,'GSIS - Policy Loan:',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$policyLoanAmount,0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end

//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(55.5,5,'GSIS - ELA:',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$elaLoanAmount,0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(55.5,5,'GSIS - Optional Insurance:',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$optionalInsuranceAmount,0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end

//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(46.5,5,'GSIS - Optional Loan:',0,0);
$pdf->Cell(9,3,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$optionalAmount,0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end


//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(55.5,5,'GSIS - GFAL:',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$gfalAmount,0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end


//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(55.5,5,'GSIS - HIP',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$hipAmount,0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end


//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(55.5,5,'GSIS - CPL:',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$cplAmount,0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end

//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(55.5,5,'GSIS - SOS:',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$sosAmount,0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end

//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(55.5,5,'GSIS - Educ:',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$educAmount,0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(55.5,5,'GSIS - E Card:',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$eCardAmount,0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(55.5,5,'HDMF - Contribution:',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$contributionAmount ,0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(55.5,5,'HDMF - MPL:',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$mplAmount,0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(55.5,5,'HDMF - Real State:',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$realStateAmount,0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(55.5,5,'HDMF - Emergency',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$emergencyAmount,0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(55.5,5,'HDMF - MP2:',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$MP2Amount,0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(55.5,5,'Landbank:',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$landbankAmount,0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(55.5,5,'Undertime:',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$undertimededuct,0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(55.5,5,'Leave without Pay:',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$absences,0,0);
$pdf->Cell(2,5,'',0,1);
//TOTALS
$pdf->Cell(1,5,'',0,1);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end

$pdf->Cell(336,0.2,'',1,1);//end of line

endwhile;

//GRAND TOTAL
$pdf->SetFont('Arial','','8');

//EMPLOYEE
$pdf->Cell(42,5,'GRAND TOTAL FOR',0,0);
$pdf->Cell(42,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'Basic',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$GTbpay,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'Philhealth',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$GTph,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'Total Earnings',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$GTE,0,0,'R');
$pdf->Cell(2,5,'',0,1);//end

//EMPLOYEE
$pdf->Cell(84,3,$payperiod,0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'Regular OT',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$GTotpay,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'GSIS',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$GTsss,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'Total Deductions',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$GTD,0,0,'R');
$pdf->Cell(2,5,'',0,1);//end

//EMPLOYEE
$pdf->Cell(4,5,'',0,0);
$pdf->Cell(80,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'PAG-IBIG',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$GTpagibig,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(4,5,'',0,0);
$pdf->Cell(80,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'Withholding Tax ',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$GTwtax,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end

//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'GSIS - Integrated Insurance',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$GTia,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end

//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'GSIS - MPL',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$GTpagibigloan,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'GSIS - Salary Loan',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$salaryLoanAmountFormatted,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'GSIS - Policy Loan',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$policyLoanAmountFormatted,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'GSIS - ELA',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$elaLoanAmountFormatted,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'GSIS - Optional Insurance',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$optionalInsuranceAmountFormatted ,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'GSIS - Optional Loan',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$optionalAmountFormatted,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'GSIS - GFAL',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$gfalAmountFormatted,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'GSIS - HIP',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$hipAmountFormatted,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'GSIS - CPL:',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$cplAmountFormatted,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'GSIS - SOS',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$sosAmountFormatted,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'GSIS - Educ',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$educAmountFormatted,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'GSIS - E Card',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$eCardAmountFormatted,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'HDMF - Contribution',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$contributionAmountFormatted,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'HDMF - MPL',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$mplAmountFormatted,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'HDMF - Real State',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$realStateAmountFormatted, 0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'HDMF - Emergency',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$emergencyAmountFormatted,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'HDMF - MP2',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$MP2AmountFormatted,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'Landbank',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$landbankAmount,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'Undertime',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$GTut,0,0,'R');
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,1);//end
//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'Leave without Pay',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$GTabsences,0,0,'R');
$pdf->Cell(2,5,'',0,);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'NET PAY',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,$GTN,0,0,'R');
$pdf->Cell(2,5,'',0,1);//end

//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end

//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end

//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end


//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end


//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end


//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end

//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end

//EMPLOYEE
$pdf->Cell(84,5,'',0,0);
//EARNINGS
$pdf->Cell(1,5,'',0,0);
$pdf->SetFont('Arial','B','8');
$pdf->Cell(39,5,'',0,0);
$pdf->SetFont('Arial','','8');
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0,'R');
$pdf->Cell(2,5,'',0,0);
//DEDUCTIONS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,0);
//TOTALS
$pdf->Cell(1,5,'',0,0);
$pdf->Cell(39,5,'',0,0);
$pdf->Cell(22,5,'',0,0);
$pdf->Cell(20,5,'',0,0);
$pdf->Cell(2,5,'',0,1);//end

$pdf->Cell(336,0.2,'',1,1);//end of line
// Add "Printed by" information
$pdf->SetFont('Arial','',10);
$pdf->Cell(336,5,'Printed by: ' . $adminFullName,0,1,'R'); 








$pdf->Output();
unset($_SESSION['pregisterpayperiod']);
?>
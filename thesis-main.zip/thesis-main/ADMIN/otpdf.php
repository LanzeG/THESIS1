<?php
ob_start(); // Start output buffering

include("../DBCONFIG.PHP");
include("../LoginControl.php");
include("../BASICLOGININFO.PHP");
require_once("./fpdf181/fpdf.php");

if (isset($_GET['id'])) {
    $printid = $_GET['id'];
}
$adminId = $_SESSION['adminId'];
$adminname = "SELECT first_name, last_name FROM employees where emp_id = '$adminId'";
$adminnameexecqry = mysqli_query($conn, $adminname) or die ("FAILED TO CHECK EMP ID ".mysqli_error($conn));
$adminData = mysqli_fetch_assoc($adminnameexecqry);

$adminFullName = $adminData['first_name'] . " " . $adminData['last_name'];

$printfrom = isset($_SESSION['payperiodfrom']) ? $_SESSION['payperiodfrom'] : null;
$printto = isset($_SESSION['payperiodto']) ? $_SESSION['payperiodto'] : null;
$payperiod = isset($_SESSION['payperiodrange']) ? $_SESSION['payperiodrange'] : null;

if (isset($_GET['print_all'])) {
    $payslipdetailsqry = "SELECT * FROM employees";
} elseif (isset($_GET['print_displayed'])) {
    $payslipdetailsqry = $_SESSION['printot'];
}else {
    $payslipdetailsqry = "SELECT * FROM employees WHERE emp_id = '$printid'";
}

$employeeResult = filterTable($payslipdetailsqry);

$pdf = new FPDF('P', 'mm', 'A4');
$pdf->AddPage();

 // Set general information for each employee
 $pdf->SetFont('Arial', 'B', 16);
 $pdf->Cell(0, 10, 'WEB-BASED TIME KEEPING PAYROLL SYSTEM', 0, 1, 'C');

while ($employee = mysqli_fetch_assoc($employeeResult)) {
    // Fetch and populate data specific to each employee
    $printid = $employee['emp_id'];
    $printfrom = $_SESSION['payperiodfrom'];
    $printto = $_SESSION['payperiodto'];

    // Fetch data for the employee
    $printquery = "SELECT * FROM over_time, employees 
               WHERE over_time.emp_id = employees.emp_id 
               AND over_time.emp_id = '$printid' 
               AND over_time.ot_day BETWEEN '{$_SESSION['payperiodfrom']}' AND '{$_SESSION['payperiodto']}' AND ot_remarks='Approved' 
               ORDER BY ot_day ASC";
    $printqueryexec = mysqli_query($conn, $printquery);
    $printarray = mysqli_fetch_array($printqueryexec);

    if ($printarray) {
        $prefix = $printarray['prefix_ID'];
        $idno = $printarray['emp_id'];
        $lname = $printarray['last_name'];
        $fname = $printarray['first_name'];
        $mname = $printarray['middle_name'];
        $dept = $printarray['dept_NAME'];
        $position = $printarray['position'];

        $name = "$lname, $fname $mname";
        $empID = "$prefix$idno";

       

        // Employee Information
        $pdf->SetFont('Arial', 'B', 8);
        $pdf->Cell(78, 6, '', 0, 0);
        $pdf->Cell(59, 10, 'OVERTIME INFORMATION', 0, 1); //end of line

        $pdf->SetFont('Arial', '', 8);
        $pdf->Cell(6, 3, '', 0, 0); //hspacer
        $pdf->Cell(18, 3, 'Employee ID:', 0, 0);

        $pdf->SetFont('Arial', 'B', 8);
        $pdf->Cell(120, 3, $empID, 0, 0);

        $pdf->SetFont('Arial', '', 8);
        $pdf->Cell(17, 3, 'Date Printed:', 0, 0);
        $pdf->Cell(20, 3, date("d,m,y"), 0, 1); //end of line

        $pdf->Cell(6, 3, '', 0, 0);
        $pdf->Cell(9, 3, 'Name:', 0, 0);

        $pdf->SetFont('Arial', 'B', 8);
        $pdf->Cell(129, 3, $name, 0, 0);

        $pdf->SetFont('Arial', '', 8);
        $pdf->Cell(15, 3, 'Pay Period:', 0, 0);

        $pdf->SetFont('Arial', 'B', 8);
        $pdf->Cell(20, 3, $payperiod, 0, 1); //end of line

        $pdf->SetFont('Arial', '', 8);
        $pdf->Cell(6, 3, '', 0, 0);
        $pdf->Cell(16, 3, 'Department:', 0, 0);
        $pdf->Cell(45, 3, $dept, 0, 1); //end of line

        $pdf->Cell(189, 5, '', 0, 1); //end of line

        // Overtime Table Headers
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(47, 8, 'Date', 1);
        $pdf->Cell(47, 8, 'Time', 1);
        $pdf->Cell(47, 8, 'Hourly Rate', 1);
        $pdf->Cell(47, 8, 'Overtime Pay', 1);
        $pdf->Ln();
        $pdf->SetFont('Arial', '', 9);
        // Fetch and combine overtime data and employee information
        $combinedResult = mysqli_query($conn, "SELECT over_time.*, payrollinfo.hourly_rate FROM over_time LEFT JOIN payrollinfo ON over_time.emp_id = payrollinfo.emp_id WHERE over_time.ot_day BETWEEN '$printfrom' AND '$printto' AND over_time.emp_id = '$idno'");
        $totalOvertimeSum = 0;  
        // Table Data
        while ($row = mysqli_fetch_assoc($combinedResult)) {
            $pdf->Cell(47, 8, $row['ot_day'], 1);
            $pdf->Cell(47, 8, $row['ot_hours'], 1);

            // Fetch and display hourly rate
            $hourlyRate = $row['hourly_rate'];
            $pdf->Cell(47, 8, $hourlyRate, 1);

            // Modify this calculation based on your requirement
            $totalOvertime = $row['ot_hours'] * $hourlyRate;
            $pdf->Cell(47, 8, number_format($totalOvertime, 2), 1);
            $pdf->Ln();
            $totalOvertimeSum += $totalOvertime;
        }

        // Display Total Overtime (modify this based on your requirement)
        $pdf->Cell(141, 8, 'Total', 1);
        $pdf->Cell(47, 8, number_format($totalOvertimeSum, 2), 1); // Display the total overtime sum
        $pdf->Ln();

    }
}
// Additional lines
$pdf->SetFont('Arial', '', 7);
$pdf->Cell(6, 10, '', 0, 1);
$pdf->Cell(16, 3, 'Received by:', 0, 0);
$pdf->Cell(18, 3, '__________________________', 0, 1); // end of line

$pdf->Cell(6, 5, '', 0, 0);
$pdf->Cell(100, 5, '', 0, 1); // end of line
$pdf->Cell(189, 3, '', 0, 1); // end of line
$pdf->Cell(20, 1, 'Printed by: ' . $adminFullName, 0, 1);
// Output the PDF
$pdf->Output();
ob_end_flush(); // End output buffering and flush the buffer

function filterTable($searchquery)
{
    $conn1 = mysqli_connect("localhost:3307", "root", "", "masterdb");
    $filter_Result = mysqli_query($conn1, $searchquery) or die("failed to query employees " . mysqli_error($conn1));
    return $filter_Result;
}
?>

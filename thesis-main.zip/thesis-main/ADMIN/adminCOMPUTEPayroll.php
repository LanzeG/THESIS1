<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php
include("../DBCONFIG.PHP");
include("../LoginControl.php");
include("../BASICLOGININFO.PHP");


session_start();
$adminId = $_SESSION['adminId'];

$adminname = "SELECT first_name, last_name FROM employees where emp_id = '$adminId'";
$adminnameexecqry = mysqli_query($conn, $adminname) or die ("FAILED TO CHECK EMP ID ".mysqli_error($conn));
$adminData = mysqli_fetch_assoc($adminnameexecqry);

$adminFullName = $adminData['first_name'] . " " . $adminData['last_name'];

$payID = $_GET['id'];
$payperiodfrom = $_SESSION['payperiodfrom'];
$payperiodto = $_SESSION['payperiodto'];
$payperiodrange = $_SESSION['payperiodrange'];

$enddateinit = strtotime($payperiodto);
$enddateconv = date("d", $enddateinit);

$month1 = date("m", $enddateinit);
$year = date("Y", $enddateinit);

$month = intval($month1);
$year = intval($year);

if ($month == 1) {
    // If the current month is January, set the last month to December of the previous year
    $lastMonth = 12;
    $lastYear = $year - 1;
} else {
    // Otherwise, subtract 1 from the current month and keep the current year
    $lastMonth = $month - 1;
    $lastYear = $year;
}

// Get the last month's 16th day
$lastMonth16 = date_create_from_format('Y-m-d', "$lastYear-" . sprintf('%02d', $lastMonth) . "-16");

// Get the current month's 15th day
$currentMonth15 = date_create_from_format('Y-m-d', "$year-$month-15");

// Debugging statement
// echo "Last Month's 16th Day: " . $currentMonth15->format('Y-m-d') . PHP_EOL;
// echo "Last Month's 16th Day: " . $lastMonth16->format('Y-m-d') . PHP_EOL;

/**GET EMPLOYEE INFORMATION**/

$getempinfoquery = "SELECT * FROM employees WHERE emp_id = '$payID'";
$getempinfoexecquery = mysqli_query($conn,$getempinfoquery) or die ("FAILED TO GET PAY INFO ".mysqli_error($conn));
$getempinfoarray = mysqli_fetch_array($getempinfoexecquery);

if ($getempinfoarray){
	$prefix = $getempinfoarray['prefix_ID'];
	$idno = $getempinfoarray['emp_id'];
	$lname = $getempinfoarray['last_name'];
	$fname = $getempinfoarray['first_name'];
	$mname = $getempinfoarray['middle_name'];
	$dept = $getempinfoarray['dept_NAME'];
	$relstatus = $getempinfoarray['rel_status'];
	$numberofchildren = $getempinfoarray['num_children'];
	$emptype = $getempinfoarray['employment_TYPE'];

  $name = "$lname, $fname $mname";
  $empID = "$prefix$idno";

}

// Set $currentDate to $payperiodfrom
$currentDate = date('Y-m-d', strtotime($payperiodfrom));

// Extract the day of the month
$dayOfMonth = date('d', strtotime($currentDate));



    
			//echo "It's within the 16-30 pay period range.";
			if ($emptype == 'Permanent'){
				// echo "Permanent.";
								//check if processed already
								$searchquery = "SELECT * FROM PAY_PER_PERIOD WHERE emp_id = '$payID' AND pperiod_range = '$payperiodrange'";
								$searchexecquery = mysqli_query($conn,$searchquery) or die ("FAILED TO SEARCH ".mysqli_error($conn));
								$searchrows = mysqli_num_rows($searchexecquery);
								$searcharray = mysqli_fetch_array($searchexecquery);

								if ($searchrows >= 1){

									
									?>
						
											<script>
											document.addEventListener('DOMContentLoaded', function() {
												swal({
												//  title: "Good job!",
												text: "Payroll this pay period has already been processed.",
												icon: "success",
												button: "OK",
												}).then(function() {
													// window.location.href = 'adminMasterfile.php'; // Replace 'your_new_page.php' with the actual URL
													window.close()
												});
											});
										</script>
										<?php
									// header("Location: adminPAYROLLProcess.php");
									

								} else {
									//get undertimes
									$timekeepinfoquery = "SELECT SUM(hours_work) as hourswork, SUM(undertime_hours) as undertimehours FROM TIME_KEEPING WHERE emp_id = '$payID' AND timekeep_day BETWEEN '" . $lastMonth16->format('Y-m-d') . "' AND '" . $currentMonth15->format('Y-m-d') . "' ORDER BY timekeep_day ASC";
								$timekeepinfoexecquery = mysqli_query($conn,$timekeepinfoquery) or die ("FAILED TO GET TIMEKEEPINFO ". mysqli_error($conn));
												$timekeepinfoarray = mysqli_fetch_array($timekeepinfoexecquery);

												if ($timekeepinfoarray){

													
													$hw = $timekeepinfoarray['hourswork'];
													$undertimehours = $timekeepinfoarray['undertimehours'];

												}
								//get absences
								$absencesfoquery = "SELECT COUNT(absence_id) FROM absences WHERE emp_id = '$payID' AND absence_date BETWEEN '" . $lastMonth16->format('Y-m-d') . "' AND '" . $currentMonth15->format('Y-m-d') . "'";
								$absencesfoexecquery = mysqli_query($conn, $absencesfoquery) or die ("FAILED TO GET absencesFO " . mysqli_error($conn));

								// Fetch the result into an array
								$absencesfoarray = mysqli_fetch_array($absencesfoexecquery);

								// Access the count value
								$absencesCount = $absencesfoarray[0];
								
								//get payroll infro
								$payinfoquery = "SELECT * FROM PAYROLLINFO WHERE emp_id = '$payID'";
								$payinfoexecquery = mysqli_query($conn,$payinfoquery) or die ("FAILED TO GET PAY INFO ".mysqli_error($conn));
								$payinfoarray = mysqli_fetch_array($payinfoexecquery);

								if($payinfoarray){

									$basepay = $payinfoarray['base_pay'];
									$dailypay = $payinfoarray['daily_rate'];
									$rph = $payinfoarray['hourly_rate'];
									$gsisEE = $payinfoarray['gsisEE'];
									$phEE = $payinfoarray['ph_EE'];
									$pagibigEE = $payinfoarray['pagibig_EE'];

									$totalut = $undertimehours * $rph;
									


								}
									
									//get total loans for the month
									$totalloan = 0;
									$loanquery = "SELECT * FROM loans WHERE emp_id = '$payID' AND '" . $currentMonth15->format('Y-m-d') . "' BETWEEN start_date AND end_date AND status ='On-Going'";
									$loanexecqry = mysqli_query($conn, $loanquery) or die("FAILED TO CHECK PAG-IBIG LOANS");
									//$loanarray = mysqli_fetch_array($loanexecqry);


									if (mysqli_num_rows($loanexecqry) > 0) {
										// Fetch each row of loan data
										while ($loanrow = mysqli_fetch_assoc($loanexecqry)) {
											print_r($loanrow);
											// Access individual columns like $loanrow['column_name']
											$loanID = $loanrow['loanidno'];
											$loanAmount = $loanrow['loan_amount'];
											$loan_balance = $loanrow['loan_balance'];
											$monthly_deduct = $loanrow['monthly_deduct'];
											$loan_status = $loanrow['status'];
											$noofpays = $loanrow['no_of_pays'];

											$loan_balance -= $monthly_deduct;
											$noofpays = $noofpays-1;

											if ($noofpays==0){
												$loan_status = 'Paid';
											}else{
												$loan_status = 'On-Going';
											}
											// echo 'monthly ' . $loanID;
											// echo 'monthly ' . $loanAmount;
											// echo 'monthly ' . $loan_balance;
											// echo 'monthly ' . $loan_status;
											// echo 'monthly ' . $monthly_deduct;
											$totalloan = $totalloan + $monthly_deduct;
											// echo $totalloan ;
											$updateQuery = "UPDATE loans SET loan_balance =$loan_balance, no_of_pays = $noofpays, status = '$loan_status' WHERE loanidno = $loanID";
											mysqli_query($conn, $updateQuery) or  die("FAILED TO UPDATE LOAN: " . mysqli_error($conn));
											// echo "Loan updated successfully!<br>";
										}
									} else {
										// echo "No loans found for the specified employee and date range.";
									}
									//computation of wtax and other
									$totalabsences = $absencesCount  * $dailypay;
									$totaldeduct = $totalut + $totalabsences + $gsisEE + $phEE + $pagibigEE + $totalloan;
									$totalnet = $basepay - $totaldeduct;

									switch ($totalnet){

										case ($totalnet>666667):
								
											$wtax = [($totalnet - 666667) * 0.35] +183541.80;
								
										break;
										case ($totalnet>166667):
								
											$wtax = [($totalnet - 166667) * 0.30] +33541.80;
								
										break;
										case ($totalnet>66667):
								
											$wtax = [($totalnet - 66667) * 0.25] + 8541.80;
								
										break;
										case ($totalnet>33333):
								
											$wtax = [($totalnet - 33333) * 0.20] + 1875.80;
								
										break;
										case ($totalnet>=20833):
								
											$wtax = [($totalnet - 20833) * 0.15];
								
										break;
										case ($totalnet<20833):
								
											$wtax = 0;
								
										break;
										
									}

									$totaldeduct +=$wtax;
									// echo $wtax;
								$savepayrollquery = "INSERT INTO PAY_PER_PERIOD (emp_id,pperiod_range,pperiod_month,pperiod_year,rate_per_hour, reg_pay, undertimehours, absences,net_pay,philhealth_deduct, sss_deduct, pagibig_deduct, tax_deduct, total_deduct, loan_deduct) VALUES 
																				('$payID','$payperiodrange','$month1','$year','$rph','$basepay', '$totalut', '$totalabsences', '$totalnet', '$phEE','$gsisEE','$pagibigEE','$wtax', $totaldeduct, $totalloan)";
								$savepayrollexecquery = mysqli_query($conn,$savepayrollquery) or die ("FAILED TO INSERT PAYROLL INFO ".mysqli_error($conn));


								$activityLog = "Payroll Computed for $fname $lname ($payperiodrange)";
								$adminActivityQuery = "INSERT INTO adminactivity_log (emp_id, adminname, activity,log_timestamp) VALUES ('$adminId','$adminFullName', '$activityLog', NOW())";
								$adminActivityResult = mysqli_query($conn, $adminActivityQuery);


								$notificationMessage = "Payroll Computed for $fname $lname ($payperiodrange)";
								$insertNotificationQuery = "INSERT INTO empnotifications (admin_id, emp_id,adminname, message, type, status) VALUES ('$adminId','$adminFullName', '$payID','$notificationMessage','Payroll','unread')";
								mysqli_query($conn, $insertNotificationQuery);

								if ($savepayrollexecquery){
									 ?>
						
									<script>
									document.addEventListener('DOMContentLoaded', function() {
										swal({
										//  title: "Good job!",
										text: "Payroll Processed",
										icon: "success",
										button: "OK",
										}).then(function() {
											// window.location.href = 'adminMasterfile.php'; // Replace 'your_new_page.php' with the actual URL
											window.close()
										});
									});
								</script>
								<?php
												
								}else{
									// echo "<script>alert('hatdof');</script>";
								}

							
							}



		
			} else if ($emptype == 'Contractual'){
				// echo "Hatdog.";
				$timekeepinfoquery = "SELECT SUM(hours_work) as hourswork, SUM(undertime_hours) as undertimehours FROM TIME_KEEPING WHERE emp_id = '$payID' AND timekeep_day BETWEEN '" . $lastMonth16->format('Y-m-d') . "' AND '" . $currentMonth15->format('Y-m-d') . "' ORDER BY timekeep_day ASC";
				$timekeepinfoexecquery = mysqli_query($conn,$timekeepinfoquery) or die ("FAILED TO GET TIMEKEEPINFO ". mysqli_error($conn));
								$timekeepinfoarray = mysqli_fetch_array($timekeepinfoexecquery);

								if ($timekeepinfoarray){

									
									$hw = $timekeepinfoarray['hourswork'];
									$undertimehours = $timekeepinfoarray['undertimehours'];

								}

								$absencesfoquery = "SELECT COUNT(absence_id) FROM absences WHERE emp_id = '$payID' AND absence_date BETWEEN '" . $lastMonth16->format('Y-m-d') . "' AND '" . $currentMonth15->format('Y-m-d') . "'";
								$absencesfoexecquery = mysqli_query($conn, $absencesfoquery) or die ("FAILED TO GET absencesFO " . mysqli_error($conn));

								// Fetch the result into an array
								$absencesfoarray = mysqli_fetch_array($absencesfoexecquery);

								// Access the count value
								$absencesCount = $absencesfoarray[0];






								/** GET HOURLY RATE INFORMATION **/

								$payinfoquery = "SELECT * FROM PAYROLLINFO WHERE emp_id = '$payID'";
								$payinfoexecquery = mysqli_query($conn,$payinfoquery) or die ("FAILED TO GET PAY INFO ".mysqli_error($conn));
								$payinfoarray = mysqli_fetch_array($payinfoexecquery);

								if($payinfoarray){

									$basepay = $payinfoarray['base_pay'];
									$dailypay = $payinfoarray['daily_rate'];
									$rph = $payinfoarray['hourly_rate'];


									$totalut = $undertimehours * $rph;
									$totalabsences = $absencesCount  * $dailypay;
									$totaldeduct = $totalut + $totalabsences;
									$totalnet = $basepay - $totaldeduct;

								}
								$searchquery = "SELECT * FROM PAY_PER_PERIOD WHERE emp_id = '$payID' AND pperiod_range = '$payperiodrange'";
								$searchexecquery = mysqli_query($conn,$searchquery) or die ("FAILED TO SEARCH ".mysqli_error($conn));
								$searchrows = mysqli_num_rows($searchexecquery);
								$searcharray = mysqli_fetch_array($searchexecquery);

								if ($searchrows >= 1){

									
									?>
						
											<script>
											document.addEventListener('DOMContentLoaded', function() {
												swal({
												//  title: "Good job!",
												text: "Payroll this pay period has already been processed.",
												icon: "success",
												button: "OK",
												}).then(function() {
													// window.location.href = 'adminMasterfile.php'; // Replace 'your_new_page.php' with the actual URL
													window.close()
												});
											});
										</script>
										<?php
									// header("Location: adminPAYROLLProcess.php");
									

								} else {

									//wtax
									switch ($totalnet){

										case ($totalnet>666667):
								
											$wtax = [($totalnet - 666667) * 0.35] +183541.80;
								
										break;
										case ($totalnet>166667):
								
											$wtax = [($totalnet - 166667) * 0.30] +33541.80;
								
										break;
										case ($totalnet>66667):
								
											$wtax = [($totalnet - 66667) * 0.25] + 8541.80;
								
										break;
										case ($totalnet>33333):
								
											$wtax = [($totalnet - 33333) * 0.20] + 1875.80;
								
										break;
										case ($totalnet>=20833):
								
											$wtax = [($totalnet - 20833) * 0.15];
								
										break;
										case ($totalnet<20833):
								
											$wtax = 0;
								
										break;
										
									}
									$totaldeduct+=$wtax;
								

								$savepayrollquery = "INSERT INTO PAY_PER_PERIOD (emp_id,pperiod_range,pperiod_month,pperiod_year,rate_per_hour, reg_pay, undertimehours, absences,net_pay) VALUES 
																				('$payID','$payperiodrange','$month','$year','$rph','$basepay', '$totalut', '$totalabsences', '$totalnet')";
								$savepayrollexecquery = mysqli_query($conn,$savepayrollquery) or die ("FAILED TO INSERT PAYROLL INFO ".mysqli_error($conn));


								$activityLog = "Payroll Computed for $payID ($payperiodrange)";
								$adminActivityQuery = "INSERT INTO adminactivity_log (emp_id, adminname, activity,log_timestamp) VALUES ('$adminId','$adminFullName', '$activityLog', NOW())";
								$adminActivityResult = mysqli_query($conn, $adminActivityQuery);


								$notificationMessage = "Payroll Computed for $fname $lname ($payperiodrange)";
								$insertNotificationQuery = "INSERT INTO empnotifications (admin_id, emp_id,adminname, message, type, status) VALUES ('$adminId','$adminFullName', '$payID','$notificationMessage','Payroll','unread')";
								mysqli_query($conn, $insertNotificationQuery);

								if ($savepayrollexecquery){
									 ?>
						
									<script>
									document.addEventListener('DOMContentLoaded', function() {
										swal({
										//  title: "Good job!",
										text: "Payroll Processed",
										icon: "success",
										button: "OK",
										}).then(function() {
											// window.location.href = 'adminMasterfile.php'; // Replace 'your_new_page.php' with the actual URL
											window.close()
										});
									});
								</script>
								<?php
												
								}else{
									// echo "<script>alert('hatdof');</script>";
								}
							
							}
				
			}

    







?>